#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import asyncio
import subprocess
import sys
import threading
import uuid
from pathlib import Path
from typing import Any, Literal

from mcp.server.fastmcp import FastMCP, Image
from mcp.types import ToolAnnotations


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SERVER_DIR = PROJECT_ROOT / "server"
WORKFLOW_FILE = PROJECT_ROOT / "skills/local-computer/SKILL.md"
if str(SERVER_DIR) not in sys.path:
    sys.path.insert(0, str(SERVER_DIR))

from bridge_server import Bridge, BridgeConfig  # noqa: E402
from codex_local_runtime import CodexLocalRuntime  # noqa: E402
from macos_computer import MacOSComputer  # noqa: E402
from context_packet import ContextPacket  # noqa: E402


READ_ONLY = ToolAnnotations(
    readOnlyHint=True,
    destructiveHint=False,
    idempotentHint=True,
    openWorldHint=False,
)
MAY_CHANGE_REPOSITORY = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=True,
    idempotentHint=False,
    openWorldHint=True,
)
LOCAL_WRITE = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=False,
    idempotentHint=False,
    openWorldHint=False,
)
LOCAL_DESTRUCTIVE = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=True,
    idempotentHint=False,
    openWorldHint=False,
)
ARBITRARY_COMMAND = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=True,
    idempotentHint=False,
    openWorldHint=True,
)
LOCAL_NOTIFICATION = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=False,
    idempotentHint=False,
    openWorldHint=False,
)


class TurnWatchdog:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._turns: dict[str, tuple[int, threading.Timer]] = {}

    @staticmethod
    def _notify(title: str, message: str) -> bool:
        if sys.platform != "darwin" or os.environ.get("CODEX_LOCAL_MAC_NOTIFICATIONS") == "0":
            return False
        script = "on run argv\n display notification (item 2 of argv) with title (item 1 of argv)\nend run"
        try:
            result = subprocess.run(["/usr/bin/osascript", "-e", script, title[:80], message[:240]],
                                    capture_output=True, timeout=5, check=False)
            return result.returncode == 0
        except (OSError, subprocess.TimeoutExpired):
            return False

    def _schedule(self, token: str, generation: int, timeout_seconds: int) -> None:
        timer = threading.Timer(
            timeout_seconds,
            self._expired,
            args=(token, generation),
        )
        timer.daemon = True
        self._turns[token] = (generation, timer)
        timer.start()

    def _expired(self, token: str, generation: int) -> None:
        with self._lock:
            current = self._turns.get(token)
            if current is None or current[0] != generation:
                return
            self._turns.pop(token, None)
        self._notify(
            "Codex Local: возможно, ответ прерван",
            "ChatGPT не подтвердил продолжение работы. Открой веб-сессию "
            "или отправь сообщение «продолжай».",
        )

    def start(self, summary: str, timeout_seconds: int) -> str:
        token = uuid.uuid4().hex
        with self._lock:
            self._schedule(token, 1, timeout_seconds)
        return token

    def checkpoint(
        self,
        token: str,
        summary: str,
        timeout_seconds: int,
        *,
        notify: bool,
    ) -> None:
        with self._lock:
            current = self._turns.get(token)
            if current is None:
                raise ValueError("Unknown or expired turn_token")
            current[1].cancel()
            generation = current[0] + 1
            self._schedule(token, generation, timeout_seconds)
        if notify:
            self._notify("Codex Local: работа продолжается", summary)

    def complete(self, token: str, summary: str) -> bool:
        with self._lock:
            current = self._turns.pop(token, None)
            if current is None:
                raise ValueError("Unknown or expired turn_token")
            current[1].cancel()
        return self._notify("Codex Local Mac: ответ готов", summary)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Expose WebChat Repo Bridge actions as MCP tools for ChatGPT."
    )
    parser.add_argument(
        "--config",
        default=str(Path(os.environ.get("CODEX_LOCAL_MAC_STATE_DIR") or Path.home() / "Library/Application Support/CodexLocalMac") / "private/bridge_config.json"),
        help="Path to the existing bridge_config.json file.",
    )
    parser.add_argument(
        "--transport",
        choices=("stdio", "streamable-http"),
        default="streamable-http",
        help="MCP transport. Streamable HTTP is the reliable macOS default.",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        choices=("127.0.0.1",),
        help="Local bind address for streamable HTTP.",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=17842,
        help="Local port for streamable HTTP.",
    )
    return parser.parse_args()


def create_server(bridge: Bridge, *, host: str, port: int) -> FastMCP:
    if host != "127.0.0.1":
        raise ValueError("MCP must bind to 127.0.0.1; use Secure MCP Tunnel for ChatGPT")
    local = CodexLocalRuntime(bridge.config.repo)
    computer = MacOSComputer()
    turn_watchdog = TurnWatchdog()
    context_packet = ContextPacket()
    mcp = FastMCP(
        "Codex Local Mac",
        instructions=("Use the complete project context already delivered by Web Pilot when available. "
                      "Follow the canonical local-computer workflow below.\n\n"
                      + WORKFLOW_FILE.read_text(encoding="utf-8")),
        host=host,
        port=port,
        log_level="WARNING",
    )

    def call(action: str, args: dict[str, Any] | None = None) -> dict[str, Any]:
        response = bridge.execute({"action": action, "args": args or {}})
        if not response.get("ok"):
            raise RuntimeError(str(response.get("error") or f"{action} failed"))
        result = response.get("result")
        if not isinstance(result, dict):
            raise RuntimeError(f"{action} returned an invalid result")
        return result

    @mcp.tool(
        name="turn_watchdog",
        title="Track the current turn and request macOS notifications",
        description=("Use start, checkpoint and complete as specified by the canonical workflow. "
                     "Returns an opaque turn_token. Completion requests a macOS notification; "
                     "delivery depends on system settings and is not evidence of UI acceptance."),
        annotations=LOCAL_NOTIFICATION,
    )
    def turn_watchdog_tool(
        action: Literal["start", "checkpoint", "complete"],
        summary: str,
        turn_token: str = "",
        timeout_seconds: int = 150,
        notify_checkpoint: bool = False,
    ) -> dict[str, Any]:
        clean_summary = summary.strip()
        if not clean_summary:
            raise ValueError("summary must not be empty")
        bounded_timeout = max(60, min(timeout_seconds, 600))
        if action == "start":
            token = turn_watchdog.start(clean_summary, bounded_timeout)
            return {
                "status": "watching",
                "turn_token": token,
                "timeout_seconds": bounded_timeout,
            }
        if not turn_token.strip():
            raise ValueError("turn_token is required for checkpoint and complete")
        token = turn_token.strip()
        if action == "checkpoint":
            turn_watchdog.checkpoint(
                token,
                clean_summary,
                bounded_timeout,
                notify=notify_checkpoint,
            )
            return {
                "status": "watching",
                "turn_token": token,
                "timeout_seconds": bounded_timeout,
            }
        notified = turn_watchdog.complete(token, clean_summary)
        return {
            "status": "completed",
            "turn_token": token,
            "notification_requested": notified,
        }

    @mcp.tool(
        title="Bridge status",
        description=(
            "Show global local-filesystem scope and drives. Optionally pass a "
            "repository path to include its Git branch and working-tree status."
        ),
        annotations=READ_ONLY,
    )
    def bridge_status(repository: str = "") -> dict[str, Any]:
        status = call("status", {"repository": repository})
        status["codex_local"] = local.system_status()
        status["computer_use"] = computer.status()
        if repository and (Path(repository) / ".harness/plans/todo-plan.md").is_file():
            status["workflow_context"] = {
                "workspace": str(Path(repository).resolve()),
                "next_action": "Use the delivered context; recover only when context is absent, incomplete or outdated.",
            }
        return status

    @mcp.tool(
        title="Read the selected project context",
        description=("Return the complete canonical Workflow Kit packet for an explicit absolute workspace. "
                     "A client such as Web Pilot can fetch it before sending the first message. "
                     "Follow the canonical local-computer workflow: use an already delivered complete packet; "
                     "call this tool only when context is absent, incomplete or needs an update. "
                     "The response has a SHA-256 digest and exact project facts. No acknowledgement is required."),
        annotations=READ_ONLY,
    )
    def workflow_context_recover(workspace: str) -> dict[str, Any]:
        return context_packet.recover(workspace)

    @mcp.tool(
        title="Computer status",
        description=(
            "Return virtual-desktop geometry, cursor position, and the current "
            "foreground window. Use this before macOS UI automation."
        ),
        annotations=READ_ONLY,
    )
    def computer_status() -> dict[str, Any]:
        return computer.status()

    @mcp.tool(
        title="List visible macOS application windows",
        description=(
            "List visible top-level macOS application windows with stable numeric "
            "window_id values, titles, application names, process IDs, executable paths, and "
            "screen rectangles. Optionally filter by title substring."
        ),
        annotations=READ_ONLY,
    )
    def computer_list_windows(
        title_contains: str = "",
        max_results: int = 200,
    ) -> dict[str, Any]:
        return computer.list_windows(title_contains, max_results)

    @mcp.tool(
        title="Activate a macOS application window",
        description=(
            "Select and bring one currently visible application window to the foreground using "
            "a window_id returned by computer_list_windows."
        ),
        annotations=ARBITRARY_COMMAND,
    )
    def computer_activate_window(
        window_id: int,
        restore: bool = True,
    ) -> dict[str, Any]:
        return computer.activate_window(window_id, restore)

    @mcp.tool(
        title="Capture the macOS desktop",
        description=(
            "Capture the virtual desktop or an explicit screen rectangle as a PNG "
            "image visible to ChatGPT. Large captures are proportionally scaled to "
            "max_dimension. Coordinates in later input calls always use the original "
            "source_rect coordinate system, not scaled image pixels."
        ),
        annotations=READ_ONLY,
    )
    def computer_capture_screen(
        x: int | None = None,
        y: int | None = None,
        width: int | None = None,
        height: int | None = None,
        max_dimension: int = 1600,
        include_cursor: bool = True,
    ) -> Any:
        result = computer.capture_screen(
            x,
            y,
            width,
            height,
            max_dimension,
            include_cursor,
        )
        png = result.pop("png_bytes")
        return [result, Image(data=png, format="png")]

    @mcp.tool(
        title="Capture a macOS application window",
        description=(
            "Capture the current on-screen rectangle of one non-minimized window as "
            "a PNG image visible to ChatGPT. Activate minimized windows first."
        ),
        annotations=READ_ONLY,
    )
    def computer_capture_window(
        window_id: int,
        max_dimension: int = 1600,
        include_cursor: bool = True,
    ) -> Any:
        result = computer.capture_window(window_id, max_dimension, include_cursor)
        png = result.pop("png_bytes")
        return [result, Image(data=png, format="png")]

    @mcp.tool(
        title="Move the macOS mouse pointer",
        description=(
            "Move the pointer to absolute virtual-desktop coordinates. An optional "
            "bounded duration produces a visible smooth move."
        ),
        annotations=ARBITRARY_COMMAND,
    )
    def computer_move_mouse(
        x: int,
        y: int,
        duration_ms: int = 0,
    ) -> dict[str, Any]:
        return computer.move_mouse(x, y, duration_ms)

    @mcp.tool(
        title="Click the macOS mouse",
        description=(
            "Click at optional absolute virtual-desktop coordinates, or at the "
            "current pointer position. Coordinates are Quartz desktop points. Supports left, right, middle, x1, and x2."
        ),
        annotations=ARBITRARY_COMMAND,
    )
    def computer_click(
        x: int | None = None,
        y: int | None = None,
        button: str = "left",
        clicks: int = 1,
        interval_ms: int = 100,
    ) -> dict[str, Any]:
        return computer.click(x, y, button, clicks, interval_ms)

    @mcp.tool(
        title="Scroll the macOS mouse wheel",
        description=(
            "Scroll vertically or horizontally at optional absolute coordinates. "
            "A delta of 120 maps to 30 scroll pixels; negative values reverse."
        ),
        annotations=ARBITRARY_COMMAND,
    )
    def computer_scroll(
        delta: int,
        x: int | None = None,
        y: int | None = None,
        horizontal: bool = False,
    ) -> dict[str, Any]:
        return computer.scroll(delta, x, y, horizontal)

    @mcp.tool(
        title="Type Unicode text into macOS",
        description=(
            "Type Unicode text into the currently focused macOS control using "
            "Quartz Unicode keyboard events. Activate and click the intended field before calling."
        ),
        annotations=ARBITRARY_COMMAND,
    )
    def computer_type_text(
        text: str,
        interval_ms: int = 0,
    ) -> dict[str, Any]:
        return computer.type_text(text, interval_ms)

    @mcp.tool(
        title="Press a macOS keyboard key",
        description=(
            "Press and release one named keyboard key one or more times. Supported "
            "names include letters, digits, enter, escape, tab, arrows, home/end, "
            "pageup/pagedown, delete/backspace, cmd/option/control/shift modifiers, and F1-F20."
        ),
        annotations=ARBITRARY_COMMAND,
    )
    def computer_key_press(
        key: str,
        presses: int = 1,
        interval_ms: int = 50,
    ) -> dict[str, Any]:
        return computer.key_press(key, presses, interval_ms)

    @mcp.tool(
        title="Press a macOS keyboard shortcut",
        description=(
            "Press a 2-8 key shortcut such as ['cmd', 'shift', 's']; keys are held "
            "in order and released in reverse order."
        ),
        annotations=ARBITRARY_COMMAND,
    )
    def computer_hotkey(keys: list[str]) -> dict[str, Any]:
        return computer.hotkey(keys)

    @mcp.tool(
        title="Release macOS input state",
        description=(
            "Emergency recovery: release mouse buttons and common modifier keys "
            "after an interrupted or failed input sequence."
        ),
        annotations=ARBITRARY_COMMAND,
    )
    def computer_release_inputs() -> dict[str, Any]:
        return computer.release_all_inputs()

    @mcp.tool(
        title="List local drives",
        description="List local filesystem roots and their total, used, and free space.",
        annotations=READ_ONLY,
    )
    def list_drives() -> dict[str, Any]:
        return local.list_drives()

    @mcp.tool(
        title="Get file or directory info",
        description=(
            "Return metadata for any absolute or repository-relative path, including "
            "type, size, modification time, and SHA-256 for ordinary files."
        ),
        annotations=READ_ONLY,
    )
    def file_info(path: str) -> dict[str, Any]:
        return local.file_info(path)

    @mcp.tool(
        title="List directory",
        description=(
            "List files and directories at any local path. Relative paths resolve "
            "from the configured repository. Recursion is bounded by max_depth and "
            "does not descend into credential stores."
        ),
        annotations=READ_ONLY,
    )
    def list_directory(
        path: str = "",
        max_depth: int = 1,
        max_entries: int = 1000,
        include_hidden: bool = True,
    ) -> dict[str, Any]:
        return local.list_directory(path, max_depth, max_entries, include_hidden)

    @mcp.tool(
        title="Read local text file",
        description=(
            "Read a bounded line range from a UTF-8-compatible text file anywhere "
            "on local drives. Returns content, line counts, and SHA-256. Direct "
            "reads of obvious credential and private-key stores are blocked."
        ),
        annotations=READ_ONLY,
    )
    def read_file(
        path: str,
        start_line: int = 1,
        end_line: int = 500,
        include_line_numbers: bool = True,
    ) -> dict[str, Any]:
        return local.read_file(path, start_line, end_line, include_line_numbers)

    @mcp.tool(
        title="Read local binary file range",
        description=(
            "Read a bounded byte range from a binary file anywhere on local drives. "
            "Returns Base64 data, a compact hex preview, MIME type, size, and SHA-256. "
            "Use offset and next_offset to read large files in chunks."
        ),
        annotations=READ_ONLY,
    )
    def read_binary(
        path: str,
        offset: int = 0,
        length: int = 65_536,
    ) -> dict[str, Any]:
        return local.read_binary(path, offset, length)

    @mcp.tool(
        title="Find files",
        description=(
            "Find files below any local directory using a glob pattern such as "
            "'*.cpp' or '**/CMakeLists.txt'. Credential stores and dependency "
            "directories are excluded."
        ),
        annotations=READ_ONLY,
    )
    async def search_files(
        path: str = "",
        pattern: str = "*",
        max_results: int = 1000,
        include_hidden: bool = True,
    ) -> dict[str, Any]:
        return await asyncio.to_thread(
            local.search_files,
            path,
            pattern,
            max_results,
            include_hidden,
        )

    @mcp.tool(
        title="Search text across local files",
        description=(
            "Search text with ripgrep below any local directory. Fixed-string "
            "search is the default; set fixed=false only for regular expressions. "
            "Use glob to restrict file types. Credential stores are excluded."
        ),
        annotations=READ_ONLY,
    )
    async def search_text(
        query: str,
        path: str = "",
        fixed: bool = True,
        glob: str = "",
        max_results: int = 500,
    ) -> dict[str, Any]:
        return await asyncio.to_thread(
            local.search_text,
            query,
            path,
            fixed,
            glob,
            max_results,
        )

    @mcp.tool(
        title="Create directory",
        description=(
            "Create a directory anywhere on local drives. Existing directories are "
            "left intact."
        ),
        annotations=LOCAL_WRITE,
    )
    def make_directory(path: str, parents: bool = True) -> dict[str, Any]:
        return local.make_directory(path, parents)

    @mcp.tool(
        title="Write local text file",
        description=(
            "Create or atomically overwrite a text file anywhere on local drives. "
            "Existing files require overwrite=true. Pass expected_sha256 from a "
            "prior read to prevent overwriting concurrent changes."
        ),
        annotations=LOCAL_DESTRUCTIVE,
    )
    def write_file(
        path: str,
        content: str,
        overwrite: bool = False,
        create_parent_directories: bool = True,
        expected_sha256: str = "",
        encoding: str = "utf-8",
    ) -> dict[str, Any]:
        return local.write_file(
            path,
            content,
            overwrite,
            create_parent_directories,
            expected_sha256,
            encoding,
        )

    @mcp.tool(
        title="Write local binary file",
        description=(
            "Create or atomically overwrite a binary file from Base64 data anywhere "
            "on local drives. Existing files require overwrite=true. Pass "
            "expected_sha256 to prevent overwriting concurrent changes."
        ),
        annotations=LOCAL_DESTRUCTIVE,
    )
    def write_binary(
        path: str,
        data_base64: str,
        overwrite: bool = False,
        create_parent_directories: bool = True,
        expected_sha256: str = "",
    ) -> dict[str, Any]:
        return local.write_binary(
            path,
            data_base64,
            overwrite,
            create_parent_directories,
            expected_sha256,
        )

    @mcp.tool(
        title="Patch bytes in local binary file",
        description=(
            "Overwrite bytes at an exact offset in an existing binary file using "
            "Base64 data. The patch stays within the current file size unless "
            "allow_extend=true. Pass expected_sha256 for concurrency protection."
        ),
        annotations=LOCAL_DESTRUCTIVE,
    )
    def patch_binary(
        path: str,
        offset: int,
        data_base64: str,
        allow_extend: bool = False,
        expected_sha256: str = "",
    ) -> dict[str, Any]:
        return local.patch_binary(
            path,
            offset,
            data_base64,
            allow_extend,
            expected_sha256,
        )

    @mcp.tool(
        title="Replace exact text in file",
        description=(
            "Perform a precise exact-text replacement in a local file. The call "
            "fails unless the old text occurs exactly expected_replacements times. "
            "Pass expected_sha256 for concurrency protection."
        ),
        annotations=LOCAL_DESTRUCTIVE,
    )
    def replace_text(
        path: str,
        old_text: str,
        new_text: str,
        expected_replacements: int = 1,
        expected_sha256: str = "",
    ) -> dict[str, Any]:
        return local.replace_text(
            path,
            old_text,
            new_text,
            expected_replacements,
            expected_sha256,
        )

    @mcp.tool(
        title="Apply unified Git patch",
        description=(
            "Apply a unified diff with git apply in the selected working directory. "
            "Set check_only=true to validate without changing files, or reverse=true "
            "to reverse the patch."
        ),
        annotations=LOCAL_DESTRUCTIVE,
    )
    async def apply_patch(
        patch: str,
        working_directory: str = "",
        check_only: bool = False,
        reverse: bool = False,
    ) -> dict[str, Any]:
        return await asyncio.to_thread(
            local.apply_patch,
            patch,
            working_directory,
            check_only,
            reverse,
        )

    @mcp.tool(
        title="Copy file or directory",
        description=(
            "Copy a file or directory to another local path. Existing destinations "
            "require overwrite=true."
        ),
        annotations=LOCAL_DESTRUCTIVE,
    )
    def copy_path(source: str, destination: str, overwrite: bool = False) -> dict[str, Any]:
        return local.copy_path(source, destination, overwrite)

    @mcp.tool(
        title="Move or rename file or directory",
        description=(
            "Move or rename a local file or directory. Existing destinations require "
            "overwrite=true. Drive roots and core system roots are protected."
        ),
        annotations=LOCAL_DESTRUCTIVE,
    )
    def move_path(source: str, destination: str, overwrite: bool = False) -> dict[str, Any]:
        return local.move_path(source, destination, overwrite)

    @mcp.tool(
        title="Move path to Codex Local trash",
        description=(
            "Delete a local file or directory recoverably by moving it to Codex "
            "Local trash. Returns a trash_id for restoration. Drive roots, the user "
            "profile root, macOS, and Program Files roots are protected."
        ),
        annotations=LOCAL_DESTRUCTIVE,
    )
    def delete_path(path: str) -> dict[str, Any]:
        return local.delete_path(path)

    @mcp.tool(
        title="List Codex Local trash",
        description="List recoverable items deleted through delete_path.",
        annotations=READ_ONLY,
    )
    def list_trash() -> dict[str, Any]:
        return local.list_trash()

    @mcp.tool(
        title="Restore path from Codex Local trash",
        description=(
            "Restore a deleted item by trash_id, either to its original path or an "
            "explicit destination. Existing destinations require overwrite=true."
        ),
        annotations=LOCAL_DESTRUCTIVE,
    )
    def restore_trash(
        trash_id: str,
        destination: str = "",
        overwrite: bool = False,
    ) -> dict[str, Any]:
        return local.restore_trash(trash_id, destination, overwrite)

    @mcp.tool(
        title="Run one isolated local command",
        description=(
            "Run exactly one isolated short zsh or bash command with full local "
            "user access. Do not call this tool more than once in a user turn. If "
            "another command or follow-up check may be needed, use run_command_batch "
            "from the start, even with an initial one-item list. For builds, tests, "
            "installs, servers, or uncertain-duration work, use start_process and "
            "read_process_output instead. The hard timeout is 120 seconds."
        ),
        annotations=ARBITRARY_COMMAND,
    )
    async def run_command(
        command: str,
        working_directory: str = "",
        shell: Literal["zsh", "bash"] = "zsh",
        timeout: int = 30,
    ) -> dict[str, Any]:
        return await local.run_command_async(command, working_directory, shell, timeout)

    @mcp.tool(
        title="Preferred: run short local commands as one batch",
        description=(
            "Default tool for short shell work. Run 1-16 short zsh or bash "
            "commands through one MCP round trip. Use this from the start whenever "
            "follow-up commands may be needed; never replace it with several "
            "consecutive run_command calls. "
            "Pass commands as a list of command strings. working_directory, shell, "
            "and timeout apply to every item. Sequential execution is the safe "
            "default and can stop on "
            "the first failure. Set parallel=true only for independent read-only "
            "commands. Do not use for builds, installs, servers, or uncertain-duration "
            "work; use start_process and read_process_output for those."
        ),
        annotations=ARBITRARY_COMMAND,
    )
    async def run_command_batch(
        commands: list[str],
        working_directory: str | None = None,
        shell: Literal["zsh", "bash"] = "zsh",
        timeout: int = 30,
        parallel: bool = False,
        stop_on_error: bool = True,
    ) -> dict[str, Any]:
        command_items = []
        for command in commands:
            item: dict[str, Any] = {
                "command": command,
                "shell": shell,
                "timeout": timeout,
            }
            if working_directory is not None:
                item["working_directory"] = working_directory
            command_items.append(item)
        return await local.run_command_batch_async(
            command_items,
            parallel=parallel,
            stop_on_error=stop_on_error,
        )

    @mcp.tool(
        title="Start long-running local process",
        description=(
            "Start a background zsh or bash process with full local user "
            "access. Returns process_id. Use read_process_output with cursors until exit and no more output; use "
            "stop_process to terminate it."
        ),
        annotations=ARBITRARY_COMMAND,
    )
    def start_process(
        command: str,
        working_directory: str = "",
        shell: Literal["zsh", "bash"] = "zsh",
    ) -> dict[str, Any]:
        return local.start_process(command, working_directory, shell)

    @mcp.tool(
        title="Get background process status",
        description=(
            "Return running state, exit code, duration, and recent stdout/stderr for "
            "a process started by start_process."
        ),
        annotations=READ_ONLY,
    )
    def process_status(
        process_id: str,
        output_tail_chars: int = 20_000,
    ) -> dict[str, Any]:
        return local.processes.get(process_id, output_tail_chars)

    @mcp.tool(
        title="Read new background process output",
        description=(
            "Wait briefly for and return only new stdout/stderr from a background "
            "process. Reuse the returned stdout_cursor and stderr_cursor until the "
            "process finishes and no more output remains. This lets ChatGPT monitor "
            "long work invisibly and report the final result to the user."
        ),
        annotations=READ_ONLY,
    )
    async def read_process_output(
        process_id: str,
        stdout_cursor: int = 0,
        stderr_cursor: int = 0,
        wait_ms: int = 1_000,
        max_bytes: int = 100_000,
    ) -> dict[str, Any]:
        return await asyncio.to_thread(
            local.processes.read_output,
            process_id,
            stdout_cursor,
            stderr_cursor,
            wait_ms,
            max_bytes,
        )

    @mcp.tool(
        title="List background processes",
        description="List processes started by Codex Local in the current server session.",
        annotations=READ_ONLY,
    )
    def list_processes() -> dict[str, Any]:
        return local.processes.list()

    @mcp.tool(
        title="Stop background process",
        description=(
            "Terminate a process tree started by Codex Local. Set force=true for "
            "forced termination."
        ),
        annotations=LOCAL_DESTRUCTIVE,
    )
    def stop_process(process_id: str, force: bool = False) -> dict[str, Any]:
        return local.processes.stop(process_id, force)

    @mcp.tool(
        title="List repository tree",
        description=(
            "List safe files and directories inside any explicitly selected repository. "
            "Sensitive files, bridge state, Git internals, dependencies, and build "
            "directories are excluded."
        ),
        annotations=READ_ONLY,
    )
    def list_repository_tree(
        repository: str,
        path: str = "",
        max_depth: int = 3,
        max_entries: int = 1000,
    ) -> dict[str, Any]:
        return call(
            "tree",
            {
                "repository": repository,
                "path": path,
                "max_depth": max_depth,
                "max_entries": max_entries,
            },
        )

    @mcp.tool(
        title="Read repository file",
        description=(
            "Read a bounded line range from one safe text file inside the "
            "explicitly selected repository."
        ),
        annotations=READ_ONLY,
    )
    def read_repository_file(
        repository: str,
        path: str,
        start_line: int = 1,
        end_line: int = 400,
    ) -> dict[str, Any]:
        return call(
            "read",
            {
                "repository": repository,
                "path": path,
                "start_line": start_line,
                "end_line": end_line,
            },
        )

    @mcp.tool(
        title="Search repository",
        description=(
            "Search safe repository files with ripgrep. Fixed-string search is "
            "the default; set fixed to false only when a regular expression is "
            "actually needed."
        ),
        annotations=READ_ONLY,
    )
    def search_repository(
        repository: str,
        query: str,
        path: str = ".",
        fixed: bool = True,
        max_count: int = 200,
    ) -> dict[str, Any]:
        return call(
            "search",
            {
                "repository": repository,
                "query": query,
                "path": path,
                "fixed": fixed,
                "max_count": max_count,
            },
        )

    @mcp.tool(
        title="Git status",
        description="Return the short Git status for any explicitly selected repository.",
        annotations=READ_ONLY,
    )
    def git_status(repository: str) -> dict[str, Any]:
        return call("git_status", {"repository": repository})

    @mcp.tool(
        title="Git diff",
        description=(
            "Return the current Git diff, including safe untracked files when "
            "staged is false. Optionally restrict it to one repository-relative path."
        ),
        annotations=READ_ONLY,
    )
    def git_diff(
        repository: str,
        path: str | None = None,
        staged: bool = False,
        context: int = 3,
    ) -> dict[str, Any]:
        args: dict[str, Any] = {
            "repository": repository,
            "staged": staged,
            "context": context,
        }
        if path:
            args["path"] = path
        return call("git_diff", args)

    @mcp.tool(
        title="Git log",
        description=(
            "Return recent commits, optionally restricted to one "
            "repository-relative path."
        ),
        annotations=READ_ONLY,
    )
    def git_log(
        repository: str,
        count: int = 20,
        path: str | None = None,
    ) -> dict[str, Any]:
        args: dict[str, Any] = {"repository": repository, "count": count}
        if path:
            args["path"] = path
        return call("git_log", args)

    @mcp.tool(
        title="Git show",
        description=(
            "Show the patch and statistics for a Git revision, optionally "
            "restricted to one repository-relative path."
        ),
        annotations=READ_ONLY,
    )
    def git_show(
        repository: str,
        revision: str = "HEAD",
        path: str | None = None,
    ) -> dict[str, Any]:
        args: dict[str, Any] = {"repository": repository, "revision": revision}
        if path:
            args["path"] = path
        return call("git_show", args)

    return mcp


def main() -> None:
    args = parse_args()
    config = BridgeConfig.load(Path(args.config).expanduser().resolve())
    server = create_server(Bridge(config), host=args.host, port=args.port)
    server.run(transport=args.transport)


if __name__ == "__main__":
    main()
