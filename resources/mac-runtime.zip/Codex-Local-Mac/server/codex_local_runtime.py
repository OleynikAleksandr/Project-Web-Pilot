from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import mimetypes
import os
import re
import shutil
import signal
import subprocess
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any


MAX_OUTPUT_CHARS = 120_000
MAX_READ_BYTES = 10_000_000
MAX_BINARY_READ_BYTES = 512_000
MAX_BINARY_WRITE_BYTES = 10_000_000
DEFAULT_COMMAND_TIMEOUT = 30
MAX_COMMAND_TIMEOUT = 120
MAX_PROCESS_OUTPUT_WAIT_MS = 1_000
SEARCH_TIMEOUT = 30
MAX_COMMAND_BATCH_SIZE = 16
MAX_COMMAND_BATCH_ITEM_OUTPUT_CHARS = 20_000

# Codex Local intentionally does not expose or delegate to another coding
# agent.  Keep this guard on the generic command paths as well: otherwise a
# model can rediscover a globally installed CLI and invoke it through
# PowerShell/CMD even when no dedicated MCP tool is registered.
BLOCKED_EXTERNAL_AGENT_PATTERN = re.compile(
    r"(?<![a-z0-9_.-])claude(?:\.exe|\.cmd|\.ps1)?(?![a-z0-9_.-])"
    r"|@anthropic-ai[\\/]+claude-code"
    r"|anthropic-ai[\\/]+claude-code",
    re.IGNORECASE,
)

SENSITIVE_FILE_NAMES = {
    ".env",
    ".npmrc",
    ".pypirc",
    ".netrc",
    "bridge_config.json",
    "credentials",
    "credentials.json",
    "id_rsa",
    "id_ed25519",
}
SENSITIVE_SUFFIXES = {".pem", ".key", ".pfx", ".p12"}
SENSITIVE_DIRECTORY_NAMES = {
    ".gnupg",
    ".ssh",
    "credentialmanager",
    "credentials",
    "wallets",
    "keychains",
}
SENSITIVE_PATH_FRAGMENTS = {
    ("library", "safari"),
    ("library", "accounts"),
    ("library", "application support", "codexlocalmac", "private"),
    ("google", "chrome", "user data"),
    ("microsoft", "edge", "user data"),
    ("mozilla", "firefox", "profiles"),
    ("windows", "system32", "config", "systemprofile"),
}
SEARCH_EXCLUDES = [
    "!**/.git/**",
    "!**/.gnupg/**",
    "!**/.ssh/**",
    "!**/Keychains/**",
    "!**/Library/Safari/**",
    "!**/Library/Accounts/**",
    "!**/CodexLocalMac/private/**",
    "!**/node_modules/**",
    "!**/.venv/**",
    "!**/venv/**",
    "!**/bridge_config.json",
    "!**/.env",
    "!**/.env.*",
    "!**/credentials.json",
    "!**/*.pem",
    "!**/*.key",
    "!**/*.pfx",
    "!**/*.p12",
]


def clamp(text: str, limit: int = MAX_OUTPUT_CHARS) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + f"\n\n[TRUNCATED: {len(text) - limit} chars omitted]"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def decode_base64(data_base64: str, *, limit: int = MAX_BINARY_WRITE_BYTES) -> bytes:
    encoded = str(data_base64 or "").strip()
    if encoded.lower().startswith("data:") and "," in encoded:
        encoded = encoded.split(",", 1)[1]
    encoded = "".join(encoded.split())
    try:
        decoded = base64.b64decode(encoded, validate=True)
    except (ValueError, TypeError) as exc:
        raise ValueError("data_base64 is not valid Base64") from exc
    if len(decoded) > limit:
        raise ValueError(f"Decoded binary data is larger than {limit} bytes")
    return decoded


def is_sensitive_path(path: Path) -> bool:
    lowered_parts = tuple(part.lower() for part in path.parts)
    if path.name.lower() in SENSITIVE_FILE_NAMES:
        return True
    if path.name.lower().startswith(".env."):
        return True
    if path.suffix.lower() in SENSITIVE_SUFFIXES:
        return True
    if any(part in SENSITIVE_DIRECTORY_NAMES for part in lowered_parts):
        return True
    for fragment in SENSITIVE_PATH_FRAGMENTS:
        width = len(fragment)
        if any(lowered_parts[index : index + width] == fragment for index in range(len(lowered_parts) - width + 1)):
            return True
    return False


def command_argv(command: str, shell: str) -> list[str]:
    if not command.strip():
        raise ValueError("Command is empty")
    if shell not in {"zsh", "bash"}:
        raise ValueError("shell must be 'zsh' or 'bash'")
    # No interactive or login shell: user startup scripts must not alter tools.
    return ["/bin/" + shell, "-c", command]


def validate_command(command: str) -> None:
    if BLOCKED_EXTERNAL_AGENT_PATTERN.search(command):
        raise ValueError(
            "Launching an external coding-agent CLI is blocked in Codex Local. "
            "Run it manually outside Codex Local if you explicitly need it."
        )


@dataclass
class ProcessRecord:
    process_id: str
    command: str
    shell: str
    cwd: str
    pid: int
    started_at: float
    stdout_path: Path
    stderr_path: Path
    process: subprocess.Popen[bytes]


class ProcessRegistry:
    def __init__(self, root: Path):
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self._records: dict[str, ProcessRecord] = {}
        self._lock = threading.Lock()

    def start(self, command: str, shell: str, cwd: Path) -> dict[str, Any]:
        process_id = uuid.uuid4().hex[:12]
        stdout_path = self.root / f"{process_id}.stdout.log"
        stderr_path = self.root / f"{process_id}.stderr.log"
        creationflags = 0
        popen_kwargs: dict[str, Any] = {}
        if os.name == "nt":
            creationflags = (
                getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
                | getattr(subprocess, "CREATE_NO_WINDOW", 0)
            )
        else:
            popen_kwargs["start_new_session"] = True
        with stdout_path.open("wb") as stdout_handle, stderr_path.open("wb") as stderr_handle:
            process = subprocess.Popen(
                command_argv(command, shell),
                cwd=str(cwd),
                stdin=subprocess.DEVNULL,
                stdout=stdout_handle,
                stderr=stderr_handle,
                shell=False,
                creationflags=creationflags,
                **popen_kwargs,
            )
        record = ProcessRecord(
            process_id=process_id,
            command=command,
            shell=shell,
            cwd=str(cwd),
            pid=process.pid,
            started_at=time.time(),
            stdout_path=stdout_path,
            stderr_path=stderr_path,
            process=process,
        )
        with self._lock:
            self._records[process_id] = record
        return self._summary(record, include_output=False)

    def get(self, process_id: str, output_tail_chars: int = 20_000) -> dict[str, Any]:
        record = self._get_record(process_id)
        return self._summary(record, include_output=True, output_tail_chars=output_tail_chars)

    def list(self) -> dict[str, Any]:
        with self._lock:
            records = list(self._records.values())
        return {"processes": [self._summary(record, include_output=False) for record in records]}

    def read_output(
        self,
        process_id: str,
        stdout_cursor: int = 0,
        stderr_cursor: int = 0,
        wait_ms: int = 1_000,
        max_bytes: int = 100_000,
    ) -> dict[str, Any]:
        record = self._get_record(process_id)
        stdout_position = max(0, int(stdout_cursor))
        stderr_position = max(0, int(stderr_cursor))
        chunk_limit = max(1_024, min(int(max_bytes), 1_000_000))
        wait_limit = max(0, min(int(wait_ms), MAX_PROCESS_OUTPUT_WAIT_MS))
        deadline = time.monotonic() + (wait_limit / 1_000)

        while True:
            stdout_size = self._file_size(record.stdout_path)
            stderr_size = self._file_size(record.stderr_path)
            if stdout_position > stdout_size or stderr_position > stderr_size:
                raise ValueError("Output cursor is beyond the current log size")
            running = record.process.poll() is None
            if stdout_size > stdout_position or stderr_size > stderr_position:
                break
            if not running or time.monotonic() >= deadline:
                break
            time.sleep(0.1)

        stdout_bytes = self._read_range(record.stdout_path, stdout_position, chunk_limit)
        stderr_bytes = self._read_range(record.stderr_path, stderr_position, chunk_limit)
        stdout_next = stdout_position + len(stdout_bytes)
        stderr_next = stderr_position + len(stderr_bytes)
        stdout_size = self._file_size(record.stdout_path)
        stderr_size = self._file_size(record.stderr_path)
        exit_code = record.process.poll()
        return {
            "process_id": process_id,
            "running": exit_code is None,
            "exit_code": exit_code,
            "stdout": stdout_bytes.decode("utf-8", errors="replace"),
            "stderr": stderr_bytes.decode("utf-8", errors="replace"),
            "stdout_cursor": stdout_next,
            "stderr_cursor": stderr_next,
            "stdout_available_bytes": stdout_size,
            "stderr_available_bytes": stderr_size,
            "more_output": stdout_next < stdout_size or stderr_next < stderr_size,
            "duration_ms": int((time.time() - record.started_at) * 1000),
        }

    def stop(self, process_id: str, force: bool = False) -> dict[str, Any]:
        record = self._get_record(process_id)
        if record.process.poll() is None:
            if os.name == "nt":
                args = ["taskkill", "/PID", str(record.pid), "/T"]
                if force:
                    args.append("/F")
                subprocess.run(args, capture_output=True, timeout=20, check=False)
            else:
                group_id = os.getpgid(record.pid)
                os.killpg(group_id, signal.SIGKILL if force else signal.SIGTERM)
            try:
                record.process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                record.process.kill()
        return self._summary(record, include_output=True)

    def _get_record(self, process_id: str) -> ProcessRecord:
        with self._lock:
            record = self._records.get(process_id)
        if record is None:
            raise ValueError("Unknown process_id")
        return record

    def _summary(
        self,
        record: ProcessRecord,
        *,
        include_output: bool,
        output_tail_chars: int = 20_000,
    ) -> dict[str, Any]:
        exit_code = record.process.poll()
        result: dict[str, Any] = {
            "process_id": record.process_id,
            "pid": record.pid,
            "command": record.command,
            "shell": record.shell,
            "cwd": record.cwd,
            "running": exit_code is None,
            "exit_code": exit_code,
            "duration_ms": int((time.time() - record.started_at) * 1000),
        }
        if include_output:
            tail = max(1_000, min(int(output_tail_chars), 100_000))
            result["stdout"] = self._read_tail(record.stdout_path, tail)
            result["stderr"] = self._read_tail(record.stderr_path, tail)
        return result

    @staticmethod
    def _read_tail(path: Path, char_limit: int) -> str:
        try:
            with path.open("rb") as handle:
                size = handle.seek(0, os.SEEK_END)
                handle.seek(max(0, size - char_limit * 4))
                return handle.read().decode("utf-8", errors="replace")[-char_limit:]
        except OSError:
            return ""

    @staticmethod
    def _file_size(path: Path) -> int:
        try:
            return path.stat().st_size
        except OSError:
            return 0

    @staticmethod
    def _read_range(path: Path, offset: int, limit: int) -> bytes:
        try:
            with path.open("rb") as handle:
                handle.seek(offset)
                return handle.read(limit)
        except OSError:
            return b""


class CodexLocalRuntime:
    def __init__(self, default_cwd: Path):
        self.default_cwd = default_cwd.resolve()
        self.state_root = Path(os.environ.get("CODEX_LOCAL_MAC_STATE_DIR") or
                               Path.home() / "Library/Application Support/CodexLocalMac")
        self.state_root.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.state_root.chmod(0o700)
        self.trash_root = self.state_root / "trash"
        self.trash_root.mkdir(parents=True, exist_ok=True)
        self.processes = ProcessRegistry(self.state_root / "processes")

    def resolve_path(
        self,
        raw_path: str | None,
        *,
        must_exist: bool = False,
        allow_sensitive: bool = False,
    ) -> Path:
        text = str(raw_path or "").strip()
        candidate = Path(text).expanduser() if text else self.default_cwd
        if not candidate.is_absolute():
            candidate = self.default_cwd / candidate
        resolved = candidate.resolve(strict=False)
        if must_exist and not resolved.exists():
            raise ValueError(f"Path does not exist: {resolved}")
        if not allow_sensitive and is_sensitive_path(resolved):
            raise ValueError(
                "Direct access to credential/key storage is blocked. "
                "Use an explicitly approved command only if this access is truly required."
            )
        return resolved

    def system_status(self) -> dict[str, Any]:
        return {
            "default_cwd": str(self.default_cwd),
            "filesystem_scope": "local macOS filesystem with current user permissions",
            "platform": "macOS",
            "shells": ["zsh", "bash"],
            "drives": self.list_drives()["drives"],
            "trash": str(self.trash_root),
            "sensitive_direct_reads_blocked": True,
        }

    def list_drives(self) -> dict[str, Any]:
        drives: list[dict[str, Any]] = []
        if os.name == "nt":
            import ctypes

            mask = ctypes.windll.kernel32.GetLogicalDrives()
            roots = [Path(f"{chr(65 + index)}:\\") for index in range(26) if mask & (1 << index)]
        else:
            roots = [Path("/")] + sorted(p for p in Path("/Volumes").iterdir() if p.is_mount()) if Path("/Volumes").exists() else [Path("/")]
        for root in roots:
            try:
                usage = shutil.disk_usage(root)
                drives.append(
                    {
                        "path": str(root),
                        "total_bytes": usage.total,
                        "used_bytes": usage.used,
                        "free_bytes": usage.free,
                    }
                )
            except OSError:
                drives.append({"path": str(root), "unavailable": True})
        return {"drives": drives}

    def file_info(self, path: str) -> dict[str, Any]:
        target = self.resolve_path(path, must_exist=True, allow_sensitive=True)
        stat = target.stat()
        result: dict[str, Any] = {
            "path": str(target),
            "name": target.name,
            "is_file": target.is_file(),
            "is_directory": target.is_dir(),
            "is_symlink": target.is_symlink(),
            "size_bytes": stat.st_size,
            "modified_at": stat.st_mtime,
            "sensitive_content_blocked": is_sensitive_path(target),
        }
        if target.is_file() and stat.st_size <= 100_000_000 and not is_sensitive_path(target):
            result["sha256"] = sha256_file(target)
        return result

    def list_directory(
        self,
        path: str = "",
        max_depth: int = 1,
        max_entries: int = 1000,
        include_hidden: bool = True,
    ) -> dict[str, Any]:
        root = self.resolve_path(path, must_exist=True, allow_sensitive=True)
        if not root.is_dir():
            raise ValueError("Path is not a directory")
        depth_limit = max(0, min(int(max_depth), 8))
        entry_limit = max(1, min(int(max_entries), 10_000))
        entries: list[dict[str, Any]] = []
        stack: list[tuple[Path, int]] = [(root, 0)]
        while stack and len(entries) < entry_limit:
            current, depth = stack.pop()
            try:
                scanned = sorted(os.scandir(current), key=lambda item: item.name.lower())
            except OSError as exc:
                entries.append({"path": str(current), "error": str(exc)})
                continue
            child_directories: list[Path] = []
            for item in scanned:
                if not include_hidden and item.name.startswith("."):
                    continue
                child = Path(item.path)
                sensitive = is_sensitive_path(child)
                try:
                    is_directory = item.is_dir(follow_symlinks=False)
                    stat = item.stat(follow_symlinks=False)
                    entries.append(
                        {
                            "path": str(child),
                            "relative_path": str(child.relative_to(root)),
                            "type": "directory" if is_directory else "file",
                            "size_bytes": stat.st_size,
                            "modified_at": stat.st_mtime,
                            "sensitive_content_blocked": sensitive,
                        }
                    )
                    if is_directory and not sensitive and depth < depth_limit:
                        child_directories.append(child)
                except OSError as exc:
                    entries.append({"path": str(child), "error": str(exc)})
                if len(entries) >= entry_limit:
                    break
            stack.extend((child, depth + 1) for child in reversed(child_directories))
        return {"root": str(root), "entries": entries, "truncated": bool(stack) or len(entries) >= entry_limit}

    def read_file(
        self,
        path: str,
        start_line: int = 1,
        end_line: int = 500,
        include_line_numbers: bool = True,
    ) -> dict[str, Any]:
        target = self.resolve_path(path, must_exist=True)
        if not target.is_file():
            raise ValueError("Path is not a file")
        size = target.stat().st_size
        if size > MAX_READ_BYTES:
            raise ValueError(f"File is larger than {MAX_READ_BYTES} bytes")
        raw = target.read_text(encoding="utf-8", errors="replace").splitlines()
        start = max(1, int(start_line))
        end = max(start, min(int(end_line), start + 4_999))
        selected = raw[start - 1 : end]
        content = (
            "\n".join(f"{number}: {line}" for number, line in enumerate(selected, start=start))
            if include_line_numbers
            else "\n".join(selected)
        )
        return {
            "path": str(target),
            "start_line": start,
            "end_line": min(end, len(raw)),
            "total_lines": len(raw),
            "sha256": sha256_file(target),
            "content": clamp(content),
        }

    def read_binary(
        self,
        path: str,
        offset: int = 0,
        length: int = 65_536,
    ) -> dict[str, Any]:
        target = self.resolve_path(path, must_exist=True)
        if not target.is_file():
            raise ValueError("Path is not a file")
        size = target.stat().st_size
        start = max(0, int(offset))
        if start > size:
            raise ValueError("offset is beyond the end of the file")
        requested = max(1, min(int(length), MAX_BINARY_READ_BYTES))
        with target.open("rb") as handle:
            handle.seek(start)
            data = handle.read(requested)
        mime_type, _ = mimetypes.guess_type(target.name)
        return {
            "path": str(target),
            "offset": start,
            "bytes_read": len(data),
            "next_offset": start + len(data),
            "total_size_bytes": size,
            "end_of_file": start + len(data) >= size,
            "mime_type": mime_type or "application/octet-stream",
            "sha256": sha256_file(target),
            "data_base64": base64.b64encode(data).decode("ascii"),
            "hex_preview": data[:256].hex(" "),
        }

    def search_files(
        self,
        path: str = "",
        pattern: str = "*",
        max_results: int = 1000,
        include_hidden: bool = True,
    ) -> dict[str, Any]:
        root = self.resolve_path(path, must_exist=True, allow_sensitive=True)
        if not root.is_dir():
            raise ValueError("Search path is not a directory")
        cmd = ["rg", "--files"]
        if include_hidden:
            cmd.append("--hidden")
        for excluded in SEARCH_EXCLUDES:
            cmd.extend(["--glob", excluded])
        if pattern and pattern != "*":
            cmd.extend(["--glob", pattern])
        cmd.append(str(root))
        result = self._run_argv(cmd, self.default_cwd, timeout=SEARCH_TIMEOUT)
        lines = [line for line in str(result["stdout"]).splitlines() if line]
        limit = max(1, min(int(max_results), 10_000))
        result["matches"] = lines[:limit]
        result["truncated"] = len(lines) > limit
        result["stdout"] = ""
        return result

    def search_text(
        self,
        query: str,
        path: str = "",
        fixed: bool = True,
        glob: str = "",
        max_results: int = 500,
    ) -> dict[str, Any]:
        if not query:
            raise ValueError("Query is empty")
        root = self.resolve_path(path, must_exist=True, allow_sensitive=True)
        cmd = ["rg", "--line-number", "--column", "--no-heading", "--hidden"]
        for excluded in SEARCH_EXCLUDES:
            cmd.extend(["--glob", excluded])
        if glob:
            cmd.extend(["--glob", glob])
        if fixed:
            cmd.append("--fixed-strings")
        cmd.extend(["--", query, str(root)])
        result = self._run_argv(cmd, self.default_cwd, timeout=SEARCH_TIMEOUT)
        lines = [line for line in str(result["stdout"]).splitlines() if line]
        limit = max(1, min(int(max_results), 5_000))
        result["matches"] = lines[:limit]
        result["truncated"] = len(lines) > limit
        result["stdout"] = ""
        return result

    def make_directory(self, path: str, parents: bool = True) -> dict[str, Any]:
        target = self.resolve_path(path)
        target.mkdir(parents=parents, exist_ok=True)
        return {"path": str(target), "created": True}

    def write_file(
        self,
        path: str,
        content: str,
        overwrite: bool = False,
        create_parent_directories: bool = True,
        expected_sha256: str = "",
        encoding: str = "utf-8",
    ) -> dict[str, Any]:
        target = self.resolve_path(path)
        existed = target.exists()
        if target.exists() and not target.is_file():
            raise ValueError("Target exists and is not a file")
        if existed and not overwrite:
            raise ValueError("File already exists; set overwrite=true or use replace_text")
        if existed and expected_sha256 and sha256_file(target) != expected_sha256.lower():
            raise ValueError("File changed since it was read; expected_sha256 does not match")
        if create_parent_directories:
            target.parent.mkdir(parents=True, exist_ok=True)
        temp = target.with_name(f".{target.name}.codex-local-{uuid.uuid4().hex}.tmp")
        try:
            temp.write_text(content, encoding=encoding, newline="")
            os.replace(temp, target)
        finally:
            temp.unlink(missing_ok=True)
        return {
            "path": str(target),
            "created": not existed,
            "overwritten": existed,
            "size_bytes": target.stat().st_size,
            "sha256": sha256_file(target),
        }

    def write_binary(
        self,
        path: str,
        data_base64: str,
        overwrite: bool = False,
        create_parent_directories: bool = True,
        expected_sha256: str = "",
    ) -> dict[str, Any]:
        data = decode_base64(data_base64)
        target = self.resolve_path(path)
        existed = target.exists()
        if existed and not target.is_file():
            raise ValueError("Target exists and is not a file")
        if existed and not overwrite:
            raise ValueError("File already exists; set overwrite=true")
        if existed and expected_sha256 and sha256_file(target) != expected_sha256.lower():
            raise ValueError("File changed since it was read; expected_sha256 does not match")
        if create_parent_directories:
            target.parent.mkdir(parents=True, exist_ok=True)
        temp = target.with_name(f".{target.name}.codex-local-{uuid.uuid4().hex}.tmp")
        try:
            temp.write_bytes(data)
            os.replace(temp, target)
        finally:
            temp.unlink(missing_ok=True)
        return {
            "path": str(target),
            "created": not existed,
            "overwritten": existed,
            "size_bytes": len(data),
            "sha256": sha256_file(target),
        }

    def patch_binary(
        self,
        path: str,
        offset: int,
        data_base64: str,
        allow_extend: bool = False,
        expected_sha256: str = "",
    ) -> dict[str, Any]:
        data = decode_base64(data_base64)
        target = self.resolve_path(path, must_exist=True)
        if not target.is_file():
            raise ValueError("Path is not a file")
        if expected_sha256 and sha256_file(target) != expected_sha256.lower():
            raise ValueError("File changed since it was read; expected_sha256 does not match")
        start = max(0, int(offset))
        original_size = target.stat().st_size
        if start > original_size and not allow_extend:
            raise ValueError("offset is beyond the end of the file; set allow_extend=true")
        if start + len(data) > original_size and not allow_extend:
            raise ValueError("Patch extends beyond the end of the file; set allow_extend=true")
        with target.open("r+b") as handle:
            if start > original_size:
                handle.seek(original_size)
                handle.write(b"\x00" * (start - original_size))
            handle.seek(start)
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        return {
            "path": str(target),
            "offset": start,
            "bytes_written": len(data),
            "original_size_bytes": original_size,
            "size_bytes": target.stat().st_size,
            "sha256": sha256_file(target),
        }

    def replace_text(
        self,
        path: str,
        old_text: str,
        new_text: str,
        expected_replacements: int = 1,
        expected_sha256: str = "",
    ) -> dict[str, Any]:
        if not old_text:
            raise ValueError("old_text cannot be empty")
        target = self.resolve_path(path, must_exist=True)
        if not target.is_file():
            raise ValueError("Path is not a file")
        if expected_sha256 and sha256_file(target) != expected_sha256.lower():
            raise ValueError("File changed since it was read; expected_sha256 does not match")
        content = target.read_text(encoding="utf-8")
        count = content.count(old_text)
        expected = max(1, int(expected_replacements))
        if count != expected:
            raise ValueError(f"Expected {expected} exact replacements, found {count}")
        updated = content.replace(old_text, new_text)
        return {
            **self.write_file(
                str(target),
                updated,
                overwrite=True,
                expected_sha256=sha256_file(target),
            ),
            "replacements": count,
        }

    def apply_patch(
        self,
        patch: str,
        working_directory: str = "",
        check_only: bool = False,
        reverse: bool = False,
    ) -> dict[str, Any]:
        if not patch.strip():
            raise ValueError("Patch is empty")
        cwd = self.resolve_path(working_directory, must_exist=True, allow_sensitive=True)
        if not cwd.is_dir():
            raise ValueError("working_directory is not a directory")
        cmd = ["git", "apply", "--whitespace=nowarn"]
        if check_only:
            cmd.append("--check")
        if reverse:
            cmd.append("--reverse")
        started = time.time()
        process = self._run_git_apply(cmd, cwd, patch)
        # Git for Windows commonly has core.autocrlf=true at system scope.
        # That can reject a valid LF patch against an LF file because it expects
        # CRLF in the worktree. Retry with whitespace-tolerant matching only
        # after the exact application has failed; git apply is atomic by default.
        line_ending_retry = False
        if process.returncode != 0 and os.name == "nt":
            retry_cmd = [*cmd, "--ignore-space-change"]
            process = self._run_git_apply(retry_cmd, cwd, patch)
            line_ending_retry = process.returncode == 0
        return {
            "ok": process.returncode == 0,
            "exit_code": process.returncode,
            "stdout": clamp(process.stdout),
            "stderr": clamp(process.stderr),
            "duration_ms": int((time.time() - started) * 1000),
            "check_only": check_only,
            "reverse": reverse,
            "line_ending_retry": line_ending_retry,
        }

    def copy_path(self, source: str, destination: str, overwrite: bool = False) -> dict[str, Any]:
        src = self.resolve_path(source, must_exist=True)
        dst = self.resolve_path(destination)
        if dst.exists():
            if not overwrite:
                raise ValueError("Destination exists; set overwrite=true to replace it")
            self._remove_existing(dst)
        dst.parent.mkdir(parents=True, exist_ok=True)
        if src.is_dir():
            shutil.copytree(src, dst)
        else:
            shutil.copy2(src, dst)
        return {"source": str(src), "destination": str(dst), "copied": True}

    def move_path(self, source: str, destination: str, overwrite: bool = False) -> dict[str, Any]:
        src = self.resolve_path(source, must_exist=True)
        dst = self.resolve_path(destination)
        self._assert_not_protected_delete_target(src)
        if dst.exists():
            if not overwrite:
                raise ValueError("Destination exists; set overwrite=true to replace it")
            self._remove_existing(dst)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dst))
        return {"source": str(src), "destination": str(dst), "moved": True}

    def delete_path(self, path: str) -> dict[str, Any]:
        target = self.resolve_path(path, must_exist=True)
        self._assert_not_protected_delete_target(target)
        trash_id = f"{time.strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:10]}"
        container = self.trash_root / trash_id
        payload = container / "payload"
        container.mkdir(parents=True)
        shutil.move(str(target), str(payload))
        metadata = {
            "trash_id": trash_id,
            "original_path": str(target),
            "deleted_at": time.time(),
        }
        (container / "metadata.json").write_text(
            json.dumps(metadata, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        return {**metadata, "recoverable": True}

    def list_trash(self) -> dict[str, Any]:
        items: list[dict[str, Any]] = []
        for metadata_path in sorted(self.trash_root.glob("*/metadata.json"), reverse=True):
            try:
                items.append(json.loads(metadata_path.read_text(encoding="utf-8")))
            except (OSError, json.JSONDecodeError):
                continue
        return {"items": items}

    def restore_trash(self, trash_id: str, destination: str = "", overwrite: bool = False) -> dict[str, Any]:
        if not trash_id or any(character not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-" for character in trash_id):
            raise ValueError("Invalid trash_id")
        container = self.trash_root / trash_id
        metadata_path = container / "metadata.json"
        payload = container / "payload"
        if not metadata_path.is_file() or not payload.exists():
            raise ValueError("Trash item not found")
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        target = self.resolve_path(destination or str(metadata["original_path"]))
        if target.exists():
            if not overwrite:
                raise ValueError("Restore destination exists; set overwrite=true to replace it")
            self._remove_existing(target)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(payload), str(target))
        shutil.rmtree(container, ignore_errors=True)
        return {"trash_id": trash_id, "restored_to": str(target)}

    def run_command(
        self,
        command: str,
        working_directory: str = "",
        shell: str = "zsh",
        timeout: int = DEFAULT_COMMAND_TIMEOUT,
    ) -> dict[str, Any]:
        validate_command(command)
        cwd = self.resolve_path(working_directory, must_exist=True, allow_sensitive=True)
        if not cwd.is_dir():
            raise ValueError("working_directory is not a directory")
        return self._run_argv(
            command_argv(command, shell),
            cwd,
            timeout=max(1, min(int(timeout), MAX_COMMAND_TIMEOUT)),
        )

    async def run_command_async(
        self,
        command: str,
        working_directory: str = "",
        shell: str = "zsh",
        timeout: int = DEFAULT_COMMAND_TIMEOUT,
    ) -> dict[str, Any]:
        validate_command(command)
        cwd = self.resolve_path(working_directory, must_exist=True, allow_sensitive=True)
        if not cwd.is_dir():
            raise ValueError("working_directory is not a directory")
        return await self._run_argv_async(
            command_argv(command, shell),
            cwd,
            timeout=max(1, min(int(timeout), MAX_COMMAND_TIMEOUT)),
        )

    async def run_command_batch_async(
        self,
        commands: list[dict[str, Any]],
        parallel: bool = False,
        stop_on_error: bool = True,
    ) -> dict[str, Any]:
        if not commands:
            raise ValueError("commands must contain at least one command")
        if len(commands) > MAX_COMMAND_BATCH_SIZE:
            raise ValueError(
                f"commands cannot contain more than {MAX_COMMAND_BATCH_SIZE} items"
            )

        normalized: list[dict[str, Any]] = []
        for index, item in enumerate(commands):
            if not isinstance(item, dict):
                raise ValueError(f"commands[{index}] must be an object")
            command = item.get("command")
            if not isinstance(command, str):
                raise ValueError(f"commands[{index}].command must be a string")
            validate_command(command)
            working_directory = item.get("working_directory", "")
            shell = item.get("shell", "zsh")
            timeout = item.get("timeout", DEFAULT_COMMAND_TIMEOUT)
            label = item.get("label", "")
            if not isinstance(working_directory, str):
                raise ValueError(
                    f"commands[{index}].working_directory must be a string"
                )
            if not isinstance(shell, str):
                raise ValueError(f"commands[{index}].shell must be a string")
            if not isinstance(label, str):
                raise ValueError(f"commands[{index}].label must be a string")
            try:
                bounded_timeout = max(1, min(int(timeout), MAX_COMMAND_TIMEOUT))
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    f"commands[{index}].timeout must be an integer"
                ) from exc
            cwd = self.resolve_path(
                working_directory,
                must_exist=True,
                allow_sensitive=True,
            )
            if not cwd.is_dir():
                raise ValueError(
                    f"commands[{index}].working_directory is not a directory"
                )
            normalized.append(
                {
                    "index": index,
                    "label": label,
                    "argv": command_argv(command, shell),
                    "cwd": cwd,
                    "timeout": bounded_timeout,
                }
            )

        started = time.time()

        async def run_one(spec: dict[str, Any]) -> dict[str, Any]:
            result = await self._run_argv_async(
                spec["argv"],
                spec["cwd"],
                spec["timeout"],
            )
            result["stdout"] = clamp(
                result["stdout"],
                MAX_COMMAND_BATCH_ITEM_OUTPUT_CHARS,
            )
            result["stderr"] = clamp(
                result["stderr"],
                MAX_COMMAND_BATCH_ITEM_OUTPUT_CHARS,
            )
            return {
                "index": spec["index"],
                "label": spec["label"],
                **result,
            }

        results: list[dict[str, Any]] = []
        if parallel:
            results = list(await asyncio.gather(*(run_one(spec) for spec in normalized)))
        else:
            for spec in normalized:
                result = await run_one(spec)
                results.append(result)
                if stop_on_error and not result["ok"]:
                    break

        succeeded = sum(1 for result in results if result["ok"])
        return {
            "ok": len(results) == len(normalized) and succeeded == len(results),
            "requested": len(normalized),
            "completed": len(results),
            "succeeded": succeeded,
            "failed": sum(1 for result in results if not result["ok"]),
            "stopped_early": len(results) < len(normalized),
            "parallel": parallel,
            "duration_ms": int((time.time() - started) * 1000),
            "results": results,
        }

    def start_process(
        self,
        command: str,
        working_directory: str = "",
        shell: str = "zsh",
    ) -> dict[str, Any]:
        validate_command(command)
        cwd = self.resolve_path(working_directory, must_exist=True, allow_sensitive=True)
        if not cwd.is_dir():
            raise ValueError("working_directory is not a directory")
        return self.processes.start(command, shell, cwd)

    def _run_argv(self, argv: list[str], cwd: Path, timeout: int) -> dict[str, Any]:
        started = time.time()
        creationflags = 0
        popen_kwargs: dict[str, Any] = {}
        if os.name == "nt":
            creationflags = (
                getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
                | getattr(subprocess, "CREATE_NO_WINDOW", 0)
            )
        else:
            popen_kwargs["start_new_session"] = True
        process = subprocess.Popen(
            argv,
            cwd=str(cwd),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            shell=False,
            creationflags=creationflags,
            **popen_kwargs,
        )
        try:
            stdout, stderr = process.communicate(timeout=timeout)
            return {
                "ok": process.returncode == 0,
                "exit_code": process.returncode,
                "stdout": clamp(stdout),
                "stderr": clamp(stderr),
                "duration_ms": int((time.time() - started) * 1000),
            }
        except subprocess.TimeoutExpired as exc:
            if os.name == "nt":
                subprocess.run(
                    ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                    stdin=subprocess.DEVNULL,
                    capture_output=True,
                    timeout=20,
                    check=False,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
            else:
                try:
                    os.killpg(os.getpgid(process.pid), signal.SIGKILL)
                except ProcessLookupError:
                    pass
            try:
                stdout, stderr = process.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                stdout, stderr = process.communicate()
            prior_stdout = (
                exc.stdout.decode("utf-8", errors="replace")
                if isinstance(exc.stdout, bytes)
                else (exc.stdout or "")
            )
            prior_stderr = (
                exc.stderr.decode("utf-8", errors="replace")
                if isinstance(exc.stderr, bytes)
                else (exc.stderr or "")
            )
            if stdout.startswith(prior_stdout):
                prior_stdout = ""
            if stderr.startswith(prior_stderr):
                prior_stderr = ""
            return {
                "ok": False,
                "exit_code": None,
                "stdout": clamp(prior_stdout + stdout),
                "stderr": clamp(prior_stderr + stderr + f"\nTimed out after {timeout}s"),
                "duration_ms": int((time.time() - started) * 1000),
            }

    async def _run_argv_async(
        self,
        argv: list[str],
        cwd: Path,
        timeout: int,
    ) -> dict[str, Any]:
        started = time.time()
        creationflags = 0
        subprocess_kwargs: dict[str, Any] = {}
        if os.name == "nt":
            creationflags = (
                getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
                | getattr(subprocess, "CREATE_NO_WINDOW", 0)
            )
        else:
            subprocess_kwargs["start_new_session"] = True
        process = await asyncio.create_subprocess_exec(
            *argv,
            cwd=str(cwd),
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            creationflags=creationflags,
            **subprocess_kwargs,
        )
        try:
            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                process.communicate(),
                timeout=timeout,
            )
        except TimeoutError:
            await asyncio.shield(asyncio.to_thread(self._terminate_process_tree, process.pid))
            await asyncio.shield(process.wait())
            return {
                "ok": False,
                "exit_code": None,
                "stdout": "",
                "stderr": f"Timed out after {timeout}s",
                "duration_ms": int((time.time() - started) * 1000),
            }
        except asyncio.CancelledError:
            # MCP cancellation must stop the actual process group before the
            # cancelled tool task unwinds. Otherwise ChatGPT receives a late
            # result and can resurrect an apparently stopped agent loop.
            await asyncio.shield(asyncio.to_thread(self._terminate_process_tree, process.pid))
            await asyncio.shield(process.wait())
            raise
        return {
            "ok": process.returncode == 0,
            "exit_code": process.returncode,
            "stdout": clamp(stdout_bytes.decode("utf-8", errors="replace")),
            "stderr": clamp(stderr_bytes.decode("utf-8", errors="replace")),
            "duration_ms": int((time.time() - started) * 1000),
        }

    @staticmethod
    def _terminate_process_tree(pid: int) -> None:
        if os.name == "nt":
            subprocess.run(
                ["taskkill", "/PID", str(pid), "/T", "/F"],
                stdin=subprocess.DEVNULL,
                capture_output=True,
                timeout=20,
                check=False,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            return
        try:
            os.killpg(os.getpgid(pid), signal.SIGKILL)
        except ProcessLookupError:
            pass

    @staticmethod
    def _run_git_apply(
        argv: list[str],
        cwd: Path,
        patch: str,
    ) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            argv,
            cwd=str(cwd),
            input=patch,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=90,
            shell=False,
        )

    def _assert_not_protected_delete_target(self, target: Path) -> None:
        resolved = target.resolve(strict=False)
        anchor = Path(resolved.anchor)
        home = Path.home().resolve()
        protected = {anchor, home, self.state_root.resolve(),
                     *(Path(p) for p in ("/System", "/Library", "/Applications", "/Users",
                                        "/Volumes", "/usr", "/bin", "/sbin", "/private"))}
        if resolved in protected:
            raise ValueError(f"Refusing to move or delete protected root: {resolved}")

    @staticmethod
    def _remove_existing(path: Path) -> None:
        if path.is_dir() and not path.is_symlink():
            shutil.rmtree(path)
        else:
            path.unlink()
