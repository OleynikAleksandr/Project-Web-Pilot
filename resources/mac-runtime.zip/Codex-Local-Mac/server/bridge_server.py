#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import secrets
import shutil
import subprocess
import difflib
import sys
import threading
import time
import uuid
from dataclasses import dataclass
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

MAX_OUTPUT = 120_000
DEFAULT_TIMEOUT = 90

CODE_EXTENSIONS = {
    ".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx",
    ".py", ".js", ".jsx", ".ts", ".tsx", ".java", ".cs", ".go",
    ".rs", ".swift", ".kt", ".kts", ".php", ".rb", ".sh", ".ps1",
    ".bat", ".cmd", ".lua", ".cmake",
}
SKIP_DIRS = {
    ".git", ".webchat_bridge", ".agent-relay", "node_modules", ".venv",
    "venv", "dist", "__pycache__",
}
SENSITIVE_NAMES = {
    ".env", ".npmrc", ".pypirc", ".netrc", "credentials", "credentials.json",
    "id_rsa", "id_ed25519",
}
SENSITIVE_SUFFIXES = {".pem", ".key", ".pfx", ".p12"}


def is_skipped_directory(name: str) -> bool:
    lowered = name.lower()
    return lowered in SKIP_DIRS or lowered.startswith("build") or lowered.startswith("cmake-build")


def is_sensitive_relative(relative: Path) -> bool:
    parts = {part.lower() for part in relative.parts}
    name = relative.name.lower()
    return (
        ".git" in parts
        or ".webchat_bridge" in parts
        or ".agent-relay" in parts
        or name in SENSITIVE_NAMES
        or name.startswith(".env.")
        or relative.suffix.lower() in SENSITIVE_SUFFIXES
    )


def code_snapshot(repo: Path) -> dict[str, str]:
    snapshot: dict[str, str] = {}
    listed = subprocess.run(
        ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
        cwd=str(repo),
        capture_output=True,
        timeout=30,
    )
    if listed.returncode != 0:
        return snapshot
    for raw in listed.stdout.decode("utf-8", errors="replace").split("\0"):
        if not raw:
            continue
        relative = Path(raw)
        if any(is_skipped_directory(part) for part in relative.parts[:-1]):
            continue
        if is_sensitive_relative(relative):
            continue
        path = (repo / relative).resolve()
        try:
            path.relative_to(repo)
        except ValueError:
            continue
        if path.suffix.lower() not in CODE_EXTENSIONS and path.name.lower() != "cmakelists.txt":
            continue
        try:
            if not path.is_file() or path.stat().st_size > 10_000_000:
                continue
            snapshot[relative.as_posix()] = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
    return snapshot


def write_task_patch(path: Path, before: dict[str, str], after: dict[str, str]) -> bool:
    chunks: list[str] = []
    for rel in sorted(set(before) | set(after)):
        old = before.get(rel, "").splitlines(keepends=True)
        new = after.get(rel, "").splitlines(keepends=True)
        if old == new:
            continue
        chunks.extend(difflib.unified_diff(old, new, fromfile=f"a/{rel}", tofile=f"b/{rel}"))
    if not chunks:
        path.unlink(missing_ok=True)
        return False
    path.write_text("".join(chunks), encoding="utf-8", newline="\n")
    return True


def clamp(text: str, limit: int = MAX_OUTPUT) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + f"\n\n[TRUNCATED: {len(text) - limit} chars omitted]"


def run_process(args: list[str], cwd: Path, timeout: int = DEFAULT_TIMEOUT) -> dict[str, Any]:
    started = time.time()
    try:
        proc = subprocess.run(
            args,
            cwd=str(cwd),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            shell=False,
        )
        return {
            "ok": proc.returncode == 0,
            "exit_code": proc.returncode,
            "stdout": clamp(proc.stdout),
            "stderr": clamp(proc.stderr),
            "duration_ms": int((time.time() - started) * 1000),
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "ok": False,
            "exit_code": None,
            "stdout": clamp(exc.stdout or ""),
            "stderr": clamp((exc.stderr or "") + f"\nTimed out after {timeout}s"),
            "duration_ms": int((time.time() - started) * 1000),
        }
    except FileNotFoundError as exc:
        return {"ok": False, "exit_code": None, "stdout": "", "stderr": str(exc), "duration_ms": 0}


@dataclass
class BridgeConfig:
    repo: Path
    token: str
    port: int = 17841

    @classmethod
    def load(cls, path: Path) -> "BridgeConfig":
        data = json.loads(path.read_text(encoding="utf-8"))
        repo = Path(data["repo"]).expanduser().resolve()
        if not repo.is_dir():
            raise ValueError(f"Repository path does not exist: {repo}")
        token = str(data.get("token") or "").strip()
        if not token:
            raise ValueError("Missing token in config")
        return cls(
            repo=repo,
            token=token,
            port=int(data.get("port") or 17841),
        )


class Bridge:
    def __init__(self, config: BridgeConfig):
        self.config = config

    def repository_from_args(
        self,
        args: dict[str, Any],
        *,
        required: bool = False,
    ) -> Path:
        raw_repository = str(args.get("repository") or "").strip()
        if not raw_repository:
            if required:
                raise ValueError("repository is required for this operation")
            return self.config.repo
        candidate = Path(raw_repository).expanduser()
        if not candidate.is_absolute():
            candidate = self.config.repo / candidate
        repository = candidate.resolve()
        if not repository.is_dir():
            raise ValueError(f"Repository path does not exist: {repository}")
        return repository

    def resolve_inside_repo(self, relative: str, repository: Path | None = None) -> Path:
        repo = (repository or self.config.repo).resolve()
        relative = relative.replace("\\", "/").lstrip("/")
        candidate = (repo / relative).resolve()
        try:
            safe_relative = candidate.relative_to(repo)
        except ValueError as exc:
            raise ValueError("Path escapes repository") from exc
        if is_sensitive_relative(safe_relative):
            raise ValueError("Sensitive or internal path is not available through the bridge")
        return candidate

    def execute(self, request: dict[str, Any]) -> dict[str, Any]:
        action = str(request.get("action", "")).strip()
        handlers = {
            "ping": self.ping,
            "status": self.status,
            "tree": self.tree,
            "read": self.read,
            "search": self.search,
            "git_status": self.git_status,
            "git_diff": self.git_diff,
            "git_log": self.git_log,
            "git_show": self.git_show,
        }
        handler = handlers.get(action)
        if handler is None:
            return {"ok": False, "error": f"Unknown action: {action}"}

        try:
            args = request.get("args") or {}
            if not isinstance(args, dict):
                raise ValueError("args must be an object")
            result = handler(args)
            return {"ok": True, "action": action, "result": result}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def ping(self, _args: dict[str, Any]) -> dict[str, Any]:
        return {"status": "alive"}

    def status(self, args: dict[str, Any]) -> dict[str, Any]:
        if not str(args.get("repository") or "").strip():
            return {
                "workspace_root": str(self.config.repo),
                "repository_mode": "per-call",
                "repo": None,
                "branch": "",
                "git": None,
            }
        repo = self.repository_from_args(args)
        branch = run_process(["git", "branch", "--show-current"], repo, 15)
        state = run_process(["git", "status", "--short", "--branch"], repo, 15)
        return {
            "repo": str(repo),
            "repository_mode": "per-call",
            "branch": branch.get("stdout", "").strip(),
            "git": state,
        }

    def tree(self, args: dict[str, Any]) -> dict[str, Any]:
        repo = self.repository_from_args(args, required=True)
        subpath = str(args.get("path", ""))
        max_depth = max(0, min(int(args.get("max_depth", 3)), 8))
        max_entries = max(10, min(int(args.get("max_entries", 1000)), 5000))
        root = self.resolve_inside_repo(subpath, repo)
        if not root.exists() or not root.is_dir():
            raise ValueError("Tree path is not a directory")
        entries: list[str] = []
        base_depth = len(root.parts)
        for current, dirs, files in os.walk(root):
            current_path = Path(current)
            depth = len(current_path.parts) - base_depth
            dirs[:] = sorted(d for d in dirs if not is_skipped_directory(d) and depth < max_depth)
            if depth > max_depth:
                continue
            rel_dir = current_path.relative_to(repo)
            if str(rel_dir) != ".":
                entries.append(str(rel_dir).replace("\\", "/") + "/")
            for name in sorted(files):
                relative = rel_dir / name
                if is_sensitive_relative(relative):
                    continue
                entries.append(str(relative).replace("\\", "/"))
                if len(entries) >= max_entries:
                    return {"entries": entries, "truncated": True}
        return {"entries": entries, "truncated": False}

    def read(self, args: dict[str, Any]) -> dict[str, Any]:
        repo = self.repository_from_args(args, required=True)
        path = self.resolve_inside_repo(str(args.get("path", "")), repo)
        if not path.is_file():
            raise ValueError("File not found")
        if path.stat().st_size > 5_000_000:
            raise ValueError("File is too large for bridge read")
        start = max(1, int(args.get("start_line", 1)))
        end = int(args.get("end_line", start + 399))
        end = max(start, min(end, start + 1999))
        raw = path.read_text(encoding="utf-8", errors="replace").splitlines()
        selected = raw[start - 1 : end]
        numbered = "\n".join(f"{i}: {line}" for i, line in enumerate(selected, start=start))
        return {"path": str(path.relative_to(repo)).replace("\\", "/"), "start_line": start, "end_line": min(end, len(raw)), "content": clamp(numbered)}

    def search(self, args: dict[str, Any]) -> dict[str, Any]:
        repo = self.repository_from_args(args, required=True)
        query = str(args.get("query", ""))
        if not query:
            raise ValueError("Missing query")
        requested_path = str(args.get("path", "."))
        resolved_path = self.resolve_inside_repo(requested_path, repo)
        if not resolved_path.exists():
            raise ValueError("Search path does not exist")
        path = resolved_path.relative_to(repo)
        safe_path = "." if str(path) == "." else str(path)
        fixed = bool(args.get("fixed", True))
        max_count = max(1, min(int(args.get("max_count", 200)), 1000))
        cmd = [
            "rg", "--line-number", "--column", "--no-heading", "--hidden",
            "--glob", "!.git/**",
            "--glob", "!.webchat_bridge/**",
            "--glob", "!.agent-relay/**",
            "--glob", "!build*/**",
            "--glob", "!cmake-build*/**",
            "--glob", "!node_modules/**",
            "--glob", "!dist/**",
            "--glob", "!.env",
            "--glob", "!.env.*",
            "--glob", "!*.pem",
            "--glob", "!*.key",
            "--glob", "!*.pfx",
            "--glob", "!*.p12",
            "--max-count", str(max_count),
        ]
        if fixed:
            cmd.append("--fixed-strings")
        cmd.extend(["--", query, safe_path])
        return run_process(cmd, repo, 45)

    def git_status(self, args: dict[str, Any]) -> dict[str, Any]:
        repo = self.repository_from_args(args, required=True)
        return run_process(["git", "status", "--short", "--branch"], repo, 20)

    def git_diff(self, args: dict[str, Any]) -> dict[str, Any]:
        repo = self.repository_from_args(args, required=True)
        started = time.time()
        context = max(0, min(int(args.get("context", 3)), 50))
        staged = bool(args.get("staged", False))
        cmd = ["git", "diff", "--no-ext-diff", "--unified=" + str(context)]
        if staged:
            cmd.append("--cached")
        pathspec: str | None = None
        path = args.get("path")
        if path:
            safe = self.resolve_inside_repo(str(path), repo).relative_to(repo)
            pathspec = str(safe)
            cmd.extend(["--", pathspec])

        tracked = run_process(cmd, repo, 30)
        if not tracked.get("ok") or staged:
            return tracked

        untracked_cmd = ["git", "ls-files", "--others", "--exclude-standard", "-z"]
        if pathspec is not None:
            untracked_cmd.extend(["--", pathspec])
        untracked = run_process(untracked_cmd, repo, 30)
        if not untracked.get("ok"):
            return untracked

        patches: list[str] = []
        warnings: list[str] = []
        for raw_path in str(untracked.get("stdout") or "").split("\0"):
            if not raw_path:
                continue
            relative = Path(raw_path)
            if is_sensitive_relative(relative):
                continue
            created = run_process(
                [
                    "git", "diff", "--no-index", "--no-ext-diff",
                    "--unified=" + str(context), "--", "/dev/null", raw_path,
                ],
                repo,
                30,
            )
            # `git diff --no-index` returns 1 when a difference was found.
            if created.get("exit_code") not in (0, 1):
                return created
            if created.get("stdout"):
                patches.append(str(created["stdout"]).rstrip())
            if created.get("stderr"):
                warnings.append(str(created["stderr"]).rstrip())

        combined = "\n".join(
            part for part in [str(tracked.get("stdout") or "").rstrip(), *patches] if part
        )
        return {
            "ok": True,
            "exit_code": 0,
            "stdout": clamp(combined),
            "stderr": clamp("\n".join(warnings)),
            "duration_ms": int((time.time() - started) * 1000),
        }

    def git_log(self, args: dict[str, Any]) -> dict[str, Any]:
        repo = self.repository_from_args(args, required=True)
        count = max(1, min(int(args.get("count", 20)), 200))
        cmd = ["git", "log", f"-{count}", "--date=iso", "--pretty=format:%h%x09%ad%x09%an%x09%s"]
        path = args.get("path")
        if path:
            safe = self.resolve_inside_repo(str(path), repo).relative_to(repo)
            cmd.extend(["--", str(safe)])
        return run_process(cmd, repo, 30)

    def git_show(self, args: dict[str, Any]) -> dict[str, Any]:
        repo = self.repository_from_args(args, required=True)
        revision = str(args.get("revision", "HEAD"))
        if revision.startswith("-") or not re.fullmatch(r"[A-Za-z0-9_./~^{}:@+-]+", revision):
            raise ValueError("Invalid revision")
        cmd = ["git", "show", "--no-ext-diff", "--stat", "--patch", revision]
        path = args.get("path")
        if path:
            safe = self.resolve_inside_repo(str(path), repo).relative_to(repo)
            cmd.extend(["--", str(safe)])
        return run_process(cmd, repo, 45)

class Handler(BaseHTTPRequestHandler):
    bridge: Bridge

    def log_message(self, fmt: str, *args: Any) -> None:
        sys.stderr.write("[%s] %s\n" % (self.log_date_time_string(), fmt % args))

    def _cors(self) -> None:
        origin = self.headers.get("Origin", "")
        if origin.startswith("https://chatgpt.com") or origin.startswith("https://chat.openai.com") or origin.startswith("chrome-extension://"):
            self.send_header("Access-Control-Allow-Origin", origin)
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Bridge-Token")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")

    def _json(self, status: int, payload: dict[str, Any]) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self._cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _authorized(self) -> bool:
        return secrets.compare_digest(self.headers.get("X-Bridge-Token", ""), self.bridge.config.token)

    def do_OPTIONS(self) -> None:
        self.send_response(HTTPStatus.NO_CONTENT)
        self._cors()
        self.end_headers()

    def do_GET(self) -> None:
        if urlparse(self.path).path != "/health":
            self._json(404, {"ok": False, "error": "Not found"})
            return
        if not self._authorized():
            self._json(401, {"ok": False, "error": "Unauthorized"})
            return
        self._json(200, {"ok": True, "repo": str(self.bridge.config.repo)})

    def do_POST(self) -> None:
        if urlparse(self.path).path != "/execute":
            self._json(404, {"ok": False, "error": "Not found"})
            return
        if not self._authorized():
            self._json(401, {"ok": False, "error": "Unauthorized"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 2_000_000:
                raise ValueError("Invalid request size")
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            if not isinstance(payload, dict):
                raise ValueError("Request must be an object")
            result = self.bridge.execute(payload)
            self._json(200 if result.get("ok") else 400, result)
        except Exception as exc:
            self._json(400, {"ok": False, "error": str(exc)})


def make_default_config(path: Path, repo: str) -> None:
    data = {
        "repo": str(Path(repo).expanduser().resolve()),
        "token": secrets.token_urlsafe(32),
        "port": 17841,
    }
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Created {path}")
    print(f"Token: {data['token']}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Local Git/repository bridge for ChatGPT web")
    parser.add_argument("--config", default="bridge_config.json")
    parser.add_argument("--init", metavar="REPO", help="Create a config for REPO and exit")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int)
    ns = parser.parse_args()
    config_path = Path(ns.config).resolve()
    if ns.init:
        make_default_config(config_path, ns.init)
        return
    config = BridgeConfig.load(config_path)
    bridge = Bridge(config)
    Handler.bridge = bridge
    port = ns.port if ns.port is not None else config.port
    server = ThreadingHTTPServer((ns.host, port), Handler)
    print(f"WebChat bridge: http://{ns.host}:{port}")
    print(f"Repository: {config.repo}")
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
