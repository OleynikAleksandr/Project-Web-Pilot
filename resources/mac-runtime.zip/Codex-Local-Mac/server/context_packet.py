"""Read a complete Workflow Kit packet for delivery by a client or a local tool."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import subprocess
import time
from typing import Any

PROTOCOL = 'inline-context-v1'
MAX_CONTEXT_BYTES = 180000


class ContextPacket:
    @staticmethod
    def _workspace(workspace: str) -> Path:
        if not isinstance(workspace, str) or not workspace.strip() or not Path(workspace).is_absolute():
            raise ValueError('WORKSPACE_REQUIRED: supply the explicit absolute project directory')
        path = Path(workspace).resolve(strict=True)
        if not (path / '.harness/plans/todo-plan.md').is_file() or not (path / 'scripts/workflow').is_file():
            raise ValueError('WORKFLOW_NOT_INSTALLED: the selected directory has no Workflow Kit')
        return path

    def recover(self, workspace: str) -> dict[str, Any]:
        path = self._workspace(workspace)
        plan_file = path / '.harness/plans/todo-plan.md'
        before = plan_file.read_bytes()
        try:
            process = subprocess.run([str(path / 'scripts/workflow'), 'recover', '--format', 'json'],
                                     cwd=path, capture_output=True, timeout=25)
        except subprocess.TimeoutExpired as exc:
            raise ValueError('RECOVERY_TIMEOUT: workflow recover exceeded 25 seconds') from exc
        if process.returncode:
            raise ValueError('RECOVERY_FAILED: ' + process.stdout.decode('utf-8', errors='replace')[:2000])
        try:
            packet = json.loads(process.stdout)
            match = re.search(r'```json\s*\n(.*?)\n```', before.decode('utf-8'), re.S)
            plan = json.loads(match.group(1))
        except (ValueError, AttributeError) as exc:
            raise ValueError('RECOVERY_INVALID: invalid workflow packet or plan JSON') from exc
        if before != plan_file.read_bytes() or packet.get('plan_revision') != plan.get('plan_revision'):
            raise ValueError('RECOVERY_CHANGED: plan changed while reading; recover again')
        if (packet.get('ok') is not True or packet.get('completeness') != 'COMPLETE'
                or not isinstance(packet.get('text'), str) or not packet['text'].strip()
                or not isinstance(packet.get('signature'), str) or not packet['signature']):
            raise ValueError('RECOVERY_INCOMPLETE: a complete canonical packet is required')
        content = packet['text'].encode('utf-8')
        if len(content) > MAX_CONTEXT_BYTES:
            raise ValueError('RECOVERY_TOO_LARGE: split the workflow context before delivery')
        task_id = packet.get('task_id') or packet.get('next_task_id')
        try:
            task = next((t for t in plan['tasks'] if t['id'] == task_id), None)
            if task_id and task is None:
                raise ValueError('RECOVERY_INVALID: current task is missing from the plan')
            facts = {'project_id': plan['project_id'], 'project_name': plan['project_name'],
                     'plan_revision': plan['plan_revision'], 'scope_id': plan['scope_id'],
                     'execution_scope_status': plan['execution_scope_status'],
                     'delivery_status': plan['delivery_status'], 'task_id': task_id,
                     'task_title': task['title'] if task else None}
            objective, head = plan['objective'], packet['head']
        except (KeyError, TypeError) as exc:
            raise ValueError('RECOVERY_INVALID: project identity is incomplete') from exc
        return {'delivery_protocol': PROTOCOL, 'status': 'ready', 'completeness': 'COMPLETE',
                'workspace': str(path), 'facts': facts, 'objective': objective, 'head': head,
                'signature': packet['signature'], 'context': packet['text'],
                'context_sha256': hashlib.sha256(content).hexdigest(), 'context_bytes': len(content),
                'generated_at_ms': int(time.time() * 1000), 'ack_required': False}
