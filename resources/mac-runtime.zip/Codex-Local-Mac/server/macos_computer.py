"""macOS desktop backend for the original Codex Local computer tools.

Desktop coordinates are Quartz points (origin at the top-left of the main
screen). Screenshots return their source rectangle and image scaling.
"""
from __future__ import annotations

import functools
import math
from pathlib import Path
import subprocess
import tempfile
import threading
import time
from typing import Any

import AppKit as A
import ApplicationServices as AX
import Foundation as F
import Quartz as Q


KEYS = {'a':0,'s':1,'d':2,'f':3,'h':4,'g':5,'z':6,'x':7,'c':8,'v':9,'b':11,
        'q':12,'w':13,'e':14,'r':15,'y':16,'t':17,'1':18,'2':19,'3':20,'4':21,
        '6':22,'5':23,'=':24,'9':25,'7':26,'-':27,'8':28,'0':29,']':30,'o':31,
        'u':32,'[':33,'i':34,'p':35,'l':37,'j':38,"'":39,'k':40,';':41,
        '\\':42,',':43,'/':44,'n':45,'m':46,'.':47,'`':50}
KEYS.update({'enter':36,'return':36,'tab':48,'space':49,'backspace':51,'escape':53,
             'esc':53,'cmd':55,'command':55,'shift':56,'capslock':57,'option':58,
             'alt':58,'ctrl':59,'control':59,'fn':63,'delete':117,'forwarddelete':117,
             'home':115,'end':119,'pageup':116,'pagedown':121,'left':123,
             'right':124,'down':125,'up':126})
KEYS.update({f'f{i}':v for i,v in enumerate([122,120,99,118,96,97,98,100,101,109,103,111,105,107,113,106,64,79,80,90],1)})
MODIFIERS = {55:Q.kCGEventFlagMaskCommand,56:Q.kCGEventFlagMaskShift,
             58:Q.kCGEventFlagMaskAlternate,59:Q.kCGEventFlagMaskControl,63:Q.kCGEventFlagMaskSecondaryFn}


def key_code(key: str) -> int:
    try:
        return KEYS[key.lower().strip()]
    except KeyError:
        raise ValueError('Unsupported macOS key: ' + key) from None


def serialized(fn):
    @functools.wraps(fn)
    def wrapped(self, *args, **kwargs):
        with self._lock:
            return fn(self, *args, **kwargs)
    return wrapped


def rect_dict(r):
    return {'x':float(r.origin.x),'y':float(r.origin.y),
            'width':float(r.size.width),'height':float(r.size.height)}


class MacOSComputer:
    def __init__(self):
        self._lock = threading.RLock()
        self._held_keys: set[int] = set()
        self._held_buttons: set[int] = set()

    def _require_input(self):
        if not AX.AXIsProcessTrusted() or not Q.CGPreflightPostEventAccess():
            raise PermissionError('ACCESSIBILITY_REQUIRED: allow the process running Codex Local Mac in System Settings > Privacy & Security > Accessibility, then restart it.')

    def _require_capture(self):
        if not Q.CGPreflightScreenCaptureAccess():
            raise PermissionError('SCREEN_RECORDING_REQUIRED: allow the process running Codex Local Mac in System Settings > Privacy & Security > Screen & System Audio Recording, then restart it.')

    def _displays(self):
        error, displays, count = Q.CGGetActiveDisplayList(32, None, None)
        if error:
            raise RuntimeError(f'DISPLAY_LIST_FAILED: {error}')
        return [{'display_id':int(d), **rect_dict(Q.CGDisplayBounds(d))} for d in displays[:count]]

    def _desktop(self):
        displays = self._displays()
        if not displays:
            raise RuntimeError('NO_ACTIVE_DISPLAY')
        x,y = min(d['x'] for d in displays), min(d['y'] for d in displays)
        right = max(d['x']+d['width'] for d in displays)
        bottom = max(d['y']+d['height'] for d in displays)
        return {'x':x,'y':y,'width':right-x,'height':bottom-y}

    def _point(self, x=None, y=None):
        if (x is None) != (y is None):
            raise ValueError('x and y must be provided together')
        if x is None:
            p=Q.CGEventGetLocation(Q.CGEventCreate(None))
            return float(p.x),float(p.y)
        x,y=float(x),float(y)
        if not all(math.isfinite(v) for v in (x,y)) or not any(d['x'] <= x < d['x']+d['width'] and d['y'] <= y < d['y']+d['height'] for d in self._displays()):
            raise ValueError('Coordinates must fall on an active display in desktop points')
        return x,y

    def _foreground(self):
        # NSWorkspace.frontmostApplication is cached unless its run loop pumps
        # notifications. A headless MCP worker must query Accessibility live.
        system=AX.AXUIElementCreateSystemWide()
        error, app=AX.AXUIElementCopyAttributeValue(system,AX.kAXFocusedApplicationAttribute,None)
        if error or app is None:
            return None
        error, pid=AX.AXUIElementGetPid(app,None)
        if error:
            return None
        running=A.NSRunningApplication.runningApplicationWithProcessIdentifier_(pid)
        return {'pid':int(pid),'name':str(running.localizedName()) if running else None}

    def status(self) -> dict[str, Any]:
        return {'platform':'macOS','coordinate_space':'Quartz desktop points, top-left origin',
                'desktop':self._desktop(),'displays':self._displays(),'cursor':dict(zip(('x','y'),self._point())),
                'permissions':{'screen_recording':bool(Q.CGPreflightScreenCaptureAccess()),
                               'accessibility':bool(AX.AXIsProcessTrusted()),
                               'post_events':bool(Q.CGPreflightPostEventAccess())},
                'foreground_application':self._foreground()}

    def list_windows(self,title_contains='',max_results=200):
        entries=Q.CGWindowListCopyWindowInfo(Q.kCGWindowListOptionOnScreenOnly | Q.kCGWindowListExcludeDesktopElements,Q.kCGNullWindowID) or []
        windows=[]
        for w in entries:
            if w.get(Q.kCGWindowLayer,0) != 0 or not w.get(Q.kCGWindowIsOnscreen,False):
                continue
            title=str(w.get(Q.kCGWindowName,'')); app_name=str(w.get(Q.kCGWindowOwnerName,''))
            if title_contains.lower() not in (title+' '+app_name).lower():
                continue
            b=w[Q.kCGWindowBounds]
            if b['Width'] <= 0 or b['Height'] <= 0:
                continue
            app=A.NSRunningApplication.runningApplicationWithProcessIdentifier_(w[Q.kCGWindowOwnerPID])
            url=app.executableURL() if app else None
            windows.append({'window_id':int(w[Q.kCGWindowNumber]),'title':title,'application':app_name,
                            'pid':int(w[Q.kCGWindowOwnerPID]),'executable':str(url.path()) if url else None,
                            'rect':{'x':float(b['X']),'y':float(b['Y']),'width':float(b['Width']),'height':float(b['Height'])}})
            if len(windows)>=max(1,min(int(max_results),500)):
                break
        return {'windows':windows,'titles_available':bool(Q.CGPreflightScreenCaptureAccess())}

    def _window(self, window_id):
        for w in self.list_windows(max_results=500)['windows']:
            if w['window_id']==int(window_id):
                return w
        raise ValueError('WINDOW_NOT_VISIBLE: refresh computer_list_windows; the window may have closed or been minimized.')

    @serialized
    def activate_window(self,window_id,restore=True):
        self._require_input()
        w=self._window(window_id)
        app=A.NSRunningApplication.runningApplicationWithProcessIdentifier_(w['pid'])
        if app is None:
            raise ValueError('WINDOW_APPLICATION_EXITED')
        ax_app=AX.AXUIElementCreateApplication(w['pid'])
        err, windows=AX.AXUIElementCopyAttributeValue(ax_app,AX.kAXWindowsAttribute,None)
        selected=None
        if err==0:
            matches=[]
            for candidate in windows or []:
                e,title=AX.AXUIElementCopyAttributeValue(candidate,AX.kAXTitleAttribute,None)
                if e==0 and str(title)==w['title']:
                    pe,pos=AX.AXUIElementCopyAttributeValue(candidate,AX.kAXPositionAttribute,None)
                    if pe==0:
                        valid,p=AX.AXValueGetValue(pos,AX.kAXValueCGPointType,None)
                        if valid:
                            matches.append((abs(p.x-w['rect']['x'])+abs(p.y-w['rect']['y']),candidate))
            if matches:
                selected=min(matches,key=lambda v:v[0])[1]
        if selected is None:
            raise RuntimeError('WINDOW_SELECTION_FAILED: cannot identify this window through Accessibility; no input sent.')
        if restore:
            AX.AXUIElementSetAttributeValue(selected,AX.kAXMinimizedAttribute,False)
        app.activateWithOptions_(A.NSApplicationActivateIgnoringOtherApps)
        result=AX.AXUIElementPerformAction(selected,AX.kAXRaiseAction)
        if result != 0:
            raise RuntimeError(f'WINDOW_RAISE_FAILED: {result}')
        deadline=time.monotonic()+2
        verified=False
        while time.monotonic()<deadline:
            visible=self.list_windows(max_results=500)['windows']
            foreground=self._foreground()
            verified=bool(visible and visible[0]['window_id']==w['window_id'] and foreground and foreground['pid']==w['pid'])
            if verified:
                break
            time.sleep(0.05)
        if not verified:
            raise RuntimeError('WINDOW_NOT_FOREGROUND: activation was requested but could not be confirmed. Recapture before input.')
        return {'window_id':w['window_id'],'activated':True,'window':self._window(window_id)}

    @serialized
    def capture_screen(self,x=None,y=None,width=None,height=None,max_dimension=1600,include_cursor=True):
        self._require_capture()
        values=(x,y,width,height)
        if any(v is not None for v in values) and not all(v is not None for v in values):
            raise ValueError('Provide all of x, y, width and height, or none')
        source=self._desktop() if x is None else dict(zip(('x','y','width','height'),map(float,values)))
        if not all(math.isfinite(v) for v in source.values()) or source['width']<=0 or source['height']<=0 or source['width']*source['height']>64_000_000:
            raise ValueError('Invalid or oversized capture rectangle')
        desktop=self._desktop()
        if source['x']<desktop['x'] or source['y']<desktop['y'] or source['x']+source['width']>desktop['x']+desktop['width'] or source['y']+source['height']>desktop['y']+desktop['height']:
            raise ValueError('Capture rectangle lies outside the desktop bounds')
        limit=max(64,min(int(max_dimension),4096))
        # screencapture uses the supported macOS capture path on current macOS,
        # avoiding the removed CGWindowListCreateImage API.
        with tempfile.TemporaryDirectory(prefix='codex-mac-screen-') as temp:
            file=Path(temp)/'capture.png'
            rect=','.join(str(round(source[k])) for k in ('x','y','width','height'))
            args=['/usr/sbin/screencapture','-x','-t','png','-R'+rect]
            if include_cursor:
                args.append('-C')
            result=subprocess.run([*args,str(file)],capture_output=True,timeout=15)
            if result.returncode or not file.is_file():
                raise RuntimeError('SCREEN_CAPTURE_FAILED: '+result.stderr.decode('utf-8',errors='replace')[:500])
            data=F.NSData.dataWithContentsOfFile_(str(file))
            image_source=Q.CGImageSourceCreateWithData(data,None)
            if image_source is None:
                raise RuntimeError('SCREEN_CAPTURE_INVALID_IMAGE')
            image=Q.CGImageSourceCreateThumbnailAtIndex(image_source,0,{Q.kCGImageSourceCreateThumbnailFromImageAlways:True,Q.kCGImageSourceThumbnailMaxPixelSize:limit})
            if image is None:
                raise RuntimeError('SCREEN_CAPTURE_RESIZE_FAILED')
            output=F.NSMutableData.data()
            dest=Q.CGImageDestinationCreateWithData(output,'public.png',1,None)
            Q.CGImageDestinationAddImage(dest,image,None)
            if not Q.CGImageDestinationFinalize(dest):
                raise RuntimeError('SCREEN_CAPTURE_ENCODING_FAILED')
            w,h=Q.CGImageGetWidth(image),Q.CGImageGetHeight(image)
            return {'png_bytes':bytes(output),'source_rect':source,'image_width':w,'image_height':h,
                    'scale_x':w/source['width'],'scale_y':h/source['height'],
                    'coordinate_space':'Quartz desktop points; desktop_x=source_rect.x+image_x/scale_x; desktop_y=source_rect.y+image_y/scale_y'}

    def capture_window(self,window_id,max_dimension=1600,include_cursor=True):
        w=self._window(window_id)
        # A screenshot of the visible rectangle intentionally includes occluders.
        return {**self.capture_screen(**w['rect'],max_dimension=max_dimension,include_cursor=include_cursor),'window_id':int(window_id),'capture_mode':'visible desktop rectangle'}

    def _post(self,event):
        if event is None:
            raise RuntimeError('INPUT_EVENT_CREATION_FAILED')
        Q.CGEventPost(Q.kCGHIDEventTap,event)

    def _key(self,code,down):
        if down:
            self._held_keys.add(code)
        else:
            self._held_keys.discard(code)
        event=Q.CGEventCreateKeyboardEvent(None,code,down)
        flags=0
        for held in self._held_keys:
            flags |= MODIFIERS.get(held,0)
        Q.CGEventSetFlags(event,flags)
        self._post(event)

    def _release(self):
        for code in list(self._held_keys):
            self._key(code,False)
        point=self._point()
        for button in list(self._held_buttons):
            kind=Q.kCGEventLeftMouseUp if button==0 else Q.kCGEventRightMouseUp if button==1 else Q.kCGEventOtherMouseUp
            self._post(Q.CGEventCreateMouseEvent(None,kind,point,button))
            self._held_buttons.discard(button)

    @serialized
    def move_mouse(self,x,y,duration_ms=0):
        self._require_input()
        target=self._point(x,y); origin=self._point()
        duration=max(0,min(int(duration_ms),2000))/1000
        steps=max(1,round(duration*60))
        for i in range(1,steps+1):
            point=tuple(a+(b-a)*i/steps for a,b in zip(origin,target))
            self._post(Q.CGEventCreateMouseEvent(None,Q.kCGEventMouseMoved,point,0))
            if duration:
                time.sleep(duration/steps)
        return {'event_sent':True,'cursor':dict(zip(('x','y'),self._point()))}

    @serialized
    def click(self,x=None,y=None,button='left',clicks=1,interval_ms=100):
        self._require_input(); point=self._point(x,y)
        buttons={'left':0,'right':1,'middle':2,'x1':3,'x2':4}
        if button not in buttons or not 1<=int(clicks)<=5:
            raise ValueError('Use left/right/middle/x1/x2 and 1-5 clicks')
        b=buttons[button]; interval=max(0,min(int(interval_ms),500))/1000
        kinds=(Q.kCGEventLeftMouseDown,Q.kCGEventLeftMouseUp) if b==0 else (Q.kCGEventRightMouseDown,Q.kCGEventRightMouseUp) if b==1 else (Q.kCGEventOtherMouseDown,Q.kCGEventOtherMouseUp)
        try:
            for i in range(int(clicks)):
                self._held_buttons.add(b)
                for kind in kinds:
                    e=Q.CGEventCreateMouseEvent(None,kind,point,b)
                    Q.CGEventSetIntegerValueField(e,Q.kCGMouseEventClickState,i+1)
                    self._post(e)
                self._held_buttons.discard(b)
                if i+1<clicks:
                    time.sleep(interval)
        finally:
            self._release()
        return {'event_sent':True,'button':button,'clicks':clicks,'x':point[0],'y':point[1]}

    @serialized
    def scroll(self,delta,x=None,y=None,horizontal=False):
        self._require_input()
        if not -12000<=int(delta)<=12000:
            raise ValueError('delta must be between -12000 and 12000')
        if x is not None or y is not None:
            self.move_mouse(*self._point(x,y))
        amount=round(int(delta)/4)
        event=Q.CGEventCreateScrollWheelEvent(None,Q.kCGScrollEventUnitPixel,2,0 if horizontal else amount,amount if horizontal else 0)
        self._post(event)
        return {'event_sent':True,'delta':delta,'horizontal':horizontal}

    @serialized
    def type_text(self,text,interval_ms=0):
        self._require_input()
        if len(text)>10000:
            raise ValueError('Text is limited to 10000 characters per call')
        delay=max(0,min(int(interval_ms),100))/1000
        if delay*len(text)>5:
            raise ValueError('Typing duration must not exceed 5 seconds; reduce interval_ms')
        try:
            for char in text:
                for down in (True,False):
                    e=Q.CGEventCreateKeyboardEvent(None,0,down)
                    # A newly created event can inherit Command/Option from a
                    # preceding shortcut still queued in the HID event system.
                    Q.CGEventSetFlags(e,0)
                    Q.CGEventKeyboardSetUnicodeString(e,len(char.encode('utf-16-le'))//2,char)
                    self._post(e)
                if delay:
                    time.sleep(delay)
        finally:
            self._release()
        return {'event_sent':True,'characters':len(text)}

    @serialized
    def key_press(self,key,presses=1,interval_ms=50):
        self._require_input(); code=key_code(key)
        count=int(presses); delay=max(0,min(int(interval_ms),500))/1000
        if not 1<=count<=100 or count*delay>5:
            raise ValueError('Use 1-100 presses with total interval <= 5 seconds')
        try:
            for _ in range(count):
                self._key(code,True); self._key(code,False)
                if delay:
                    time.sleep(delay)
        finally:
            self._release()
        return {'event_sent':True,'key':key,'presses':count}

    @serialized
    def hotkey(self,keys):
        self._require_input()
        if not 2<=len(keys)<=8:
            raise ValueError('A shortcut needs 2-8 keys')
        codes=[key_code(k) for k in keys]
        if len(set(codes))!=len(codes):
            raise ValueError('Duplicate shortcut keys')
        try:
            for code in codes:
                self._key(code,True)
            for code in reversed(codes):
                self._key(code,False)
        finally:
            self._release()
        return {'event_sent':True,'keys':keys}

    @serialized
    def release_all_inputs(self):
        self._require_input()
        self._held_keys.update(MODIFIERS)
        self._held_buttons.update(range(5))
        self._release()
        return {'released':True}
